// ScanTrace — options.js (Version unifiée sans saisie de clés, avec alertes interactives sur les quotas bloqués)

const seEnabled = document.getElementById("seEnabled");
const seLimit = document.getElementById("seLimit");
const seMargin = document.getElementById("seMargin");
const seUsage = document.getElementById("seUsage");

const saplingEnabled = document.getElementById("saplingEnabled");
const saplingLimit = document.getElementById("saplingLimit");
const saplingMargin = document.getElementById("saplingMargin");
const saplingUsage = document.getElementById("saplingUsage");

// Éléments Hugging Face (Texte)
const hfEnabled = document.getElementById("hfEnabled");
const hfLimit = document.getElementById("hfLimit");
const hfMargin = document.getElementById("hfMargin");
const hfUsage = document.getElementById("hfUsage");

// Éléments Hugging Face (Image)
const hfImageEnabled = document.getElementById("hfImageEnabled");
const hfImageLimit = document.getElementById("hfImageLimit");
const hfImageMargin = document.getElementById("hfImageMargin");
const hfImageUsage = document.getElementById("hfImageUsage");

// Éléments Post complet
const postEnabled = document.getElementById("postEnabled");

const optSaveBtn = document.getElementById("optSaveBtn");
const saveMsg = document.getElementById("saveMsg");

const mediaTab = document.getElementById("mediaTab");
const textTab = document.getElementById("textTab");
const postTab = document.getElementById("postTab");

const mediaPanel = document.getElementById("mediaPanel");
const textPanel = document.getElementById("textPanel");
const postPanel = document.getElementById("postPanel");

let saveTimer = null;
let usageRefreshTimer = null;

// SYNCHRONISATION CHROMATIQUE EN TEMPS RÉEL AVEC LE MENU PRINCIPAL
chrome.storage.local.get("provThemeMode", (data) => {
  if (data && data.provThemeMode === "light") {
    document.body.classList.add("prov-light-mode");
  } else {
    document.body.classList.remove("prov-light-mode");
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.provThemeMode) {
    if (changes.provThemeMode.newValue === "light") {
      document.body.classList.add("prov-light-mode");
    } else {
      document.body.classList.remove("prov-light-mode");
    }
  }
});

// CONFIGURATION BRIDÉE ET AJUSTÉE POUR SÉCURISER VOTRE ENVELOPPE GRATUITE DE BÊTA
function defaultConfig() {
  return {
    sightengine: { apiUser: "", apiSecret: "", enabled: true, dailyLimit: 7, safetyMargin: 1 },
    sapling: { publicKey: "", privateKey: "", enabled: true, dailyLimit: 6, safetyMargin: 1 },
    huggingface: { apiKey: "", modelId: "openai-community/roberta-base-openai-detector", enabled: true, dailyLimit: 20, safetyMargin: 2 },
    huggingface_image: { apiKey: "", modelId: "umm-maybe/AI-image-detector", enabled: true, dailyLimit: 20, safetyMargin: 2 },
    post: { enabled: true },
    custom: [],
  };
}

async function load() {
  const { provConfig = defaultConfig() } = await chrome.storage.local.get("provConfig");
  const defaults = defaultConfig();
  const sightengine = { ...defaults.sightengine, ...provConfig.sightengine };
  const sapling = { ...defaults.sapling, ...provConfig.sapling };
  const huggingface = { ...defaults.huggingface, ...provConfig.huggingface };
  const huggingface_image = { ...defaults.huggingface_image, ...provConfig.huggingface_image };
  const post = { ...defaults.post, ...provConfig.post };

  seEnabled.checked = sightengine.enabled;
  seLimit.value = sightengine.dailyLimit;
  seMargin.value = sightengine.safetyMargin;

  saplingEnabled.checked = sapling.enabled;
  saplingLimit.value = sapling.dailyLimit;
  saplingMargin.value = sapling.safetyMargin;

  hfEnabled.checked = huggingface.enabled;
  hfLimit.value = huggingface.dailyLimit;
  hfMargin.value = huggingface.safetyMargin;

  hfImageEnabled.checked = huggingface_image.enabled;
  hfImageLimit.value = huggingface_image.dailyLimit;
  hfImageMargin.value = huggingface_image.safetyMargin;

  postEnabled.checked = post.enabled;

  await refreshUsage();
}

function showTab(kind) {
  const isMedia = kind === "media";
  const isText = kind === "text";
  const isPost = kind === "post";

  mediaTab.classList.toggle("is-active", isMedia);
  textTab.classList.toggle("is-active", isText);
  postTab.classList.toggle("is-active", isPost);

  mediaPanel.classList.toggle("is-active", isMedia);
  textPanel.classList.toggle("is-active", isText);
  postPanel.classList.toggle("is-active", isPost);

  mediaPanel.hidden = !isMedia;
  textPanel.hidden = !isText;
  postPanel.hidden = !isPost;
}

mediaTab.addEventListener("click", () => showTab("media"));
textTab.addEventListener("click", () => showTab("text"));
postTab.addEventListener("click", () => showTab("post"));

// LIAISON INTERACTIVE : Intercepte les clics sur tous les champs verrouillés pour afficher la boîte d'alerte officielle de l'administrateur [4]
const lockedFields = [
  seLimit, seMargin, hfImageLimit, hfImageMargin,
  saplingLimit, saplingMargin, hfLimit, hfMargin
];

lockedFields.forEach(field => {
  if (field) {
    field.addEventListener("click", (e) => {
      e.preventDefault();
      alert("Le nombre de requêtes par personne est bloqué par l'administrateur.\n\nPour toute demande de modification, veuillez envoyer un e-mail à : basile.ceyrac@protonmail.com");
    });
  }
});

[
  seEnabled, seLimit, seMargin, 
  saplingEnabled, saplingLimit, saplingMargin,
  hfEnabled, hfLimit, hfMargin,
  hfImageEnabled, hfImageLimit, hfImageMargin,
  postEnabled
].forEach((el) => {
  if (el) {
    el.addEventListener("input", scheduleSave);
    el.addEventListener("change", scheduleSave);
  }
});

if (optSaveBtn) {
  optSaveBtn.addEventListener("click", save);
}

function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(save, 400);
}

async function save() {
  const existing = await chrome.storage.local.get("provConfig");
  const provConfig = {
    ...(existing.provConfig || {}),
    sightengine: {
      apiUser: "", apiSecret: "", enabled: seEnabled.checked,
      dailyLimit: Number(seLimit.value) || 0, safetyMargin: Number(seMargin.value) || 0,
    },
    sapling: {
      publicKey: "", privateKey: "", enabled: saplingEnabled.checked,
      dailyLimit: Number(saplingLimit.value) || 0, safetyMargin: Number(saplingMargin.value) || 0,
    },
    huggingface: {
      apiKey: "", modelId: "openai-community/roberta-base-openai-detector", enabled: hfEnabled.checked,
      dailyLimit: Number(hfLimit.value) || 0, safetyMargin: Number(hfMargin.value) || 0,
    },
    huggingface_image: {
      apiKey: "", modelId: "umm-maybe/AI-image-detector", enabled: hfImageEnabled.checked,
      dailyLimit: Number(hfImageLimit.value) || 0, safetyMargin: Number(hfImageMargin.value) || 0,
    },
    post: {
      enabled: postEnabled.checked
    },
    custom: existing.provConfig?.custom || [],
  };

  await chrome.storage.local.set({ 
    provConfig,
    prov_hf_enabled: hfEnabled.checked,
    prov_hf_image_enabled: hfImageEnabled.checked
  });

  saveMsg.textContent = "Réglages enregistrés.";
  setTimeout(() => (saveMsg.textContent = ""), 1800);
  await refreshUsage();
}

async function refreshUsage() {
  paintUsage(seUsage, await ProvQuota.usedToday("sightengine"), Number(seLimit.value) || 0, Number(seMargin.value) || 0);
  paintUsage(saplingUsage, await ProvQuota.usedToday("sapling"), Number(saplingLimit.value) || 0, Number(saplingMargin.value) || 0);
  paintUsage(hfUsage, await ProvQuota.usedToday("huggingface"), Number(hfLimit.value) || 0, Number(hfMargin.value) || 0);
  paintUsage(hfImageUsage, await ProvQuota.usedToday("huggingface_image"), Number(hfImageLimit.value) || 0, Number(hfImageMargin.value) || 0);
}

function paintUsage(el, used, limit, margin) {
  if (!limit) {
    el.textContent = "Aucune limite définie — l’agent sera appelé sans restriction.";
    el.className = "opt-usage";
    return;
  }
  const cap = Math.max(0, limit - margin);
  el.textContent = `${used} / ${cap} requêtes utilisées aujourd’hui (quota réel : ${limit}, marge : ${margin})`;
  el.className = "opt-usage" + (used >= cap ? " opt-usage-full" : used >= cap * 0.8 ? " opt-usage-warn" : "");
}

usageRefreshTimer = setInterval(refreshUsage, 4000);
window.addEventListener("unload", () => clearInterval(usageRefreshTimer));
load();