# Provenance — Détecteur multi-agents de contenu IA

Extension Chrome (Manifest V3). Clique sur l'icône : un **panneau flottant**
s'ouvre directement dans la page (pas le petit popup Chrome classique). Ce
panneau :

- a des **coins arrondis et une ombre douce**
- est **déplaçable** : clique-glisse sur l'en-tête pour le repositionner
  n'importe où dans la fenêtre
- **reste ouvert** quoi que tu fasses sur la page (clics, scroll, saisie...)
  — seul le bouton **✕** dans l'en-tête le referme

⚠️ Limite propre à Chrome : un popup classique (`default_popup`) se ferme
**toujours** automatiquement au moindre clic à l'extérieur — c'est un
comportement imposé par le navigateur, impossible à désactiver. Pour obtenir
un panneau qui reste ouvert et déplaçable, il doit donc être injecté comme un
élément de la page elle-même (ce que fait cette extension), et non comme le
popup d'action standard. Conséquence : le panneau vit dans l'onglet en cours
et disparaît si tu navigues vers une nouvelle page ou recharges — il faut
alors recliquer sur l'icône. Il ne dépend en revanche d'aucune fenêtre système
supplémentaire.

Une fois ouvert, tu peux sélectionner une image/vidéo sur la page ou importer
un fichier local, et l'extension interroge **en parallèle** :

1. Un scanner de métadonnées **local et gratuit** (C2PA, EXIF/XMP, signatures
   d'outils IA embarquées) — toujours actif, aucune clé requise.
2. Un **agent image/vidéo intégré**, à activer avec tes propres identifiants
   API (Réglages → icône ⚙ dans le panneau). Le quota gratuit journalier est
   pré-rempli automatiquement à partir de l'offre gratuite publique du
   fournisseur ; ajuste si elle a changé.
3. Autant de **providers personnalisés** que tu veux (Hive, isgen, AI or Not,
   Winston AI, ZeroGPT, ou n'importe quelle API de détection image/vidéo) —
   à configurer toi-même dans les Réglages avec l'URL, le header d'auth et
   le mode d'envoi.
4. *(Fonctionnalité test)* **Détection de texte généré par IA** : bouton
   dédié dans le panneau, colle un texte, il est envoyé à tout provider
   personnalisé marqué comme "Texte" dans les Réglages (GPTZero,
   Originality.ai, Winston AI, Copyleaks, ZeroGPT...). Aucun agent
   texte n'est intégré par défaut — il faut en ajouter un dans les Réglages
   pour que ce bouton renvoie un résultat.

Chaque agent renvoie un score 0–1 ; l'extension calcule un **consensus**
(moyenne) et affiche le détail de chaque agent séparément, avec le scanner de
métadonnées local en plus.

## Système de quota (limite avant la limite gratuite)

Pour chaque agent (Sightengine + chaque provider personnalisé), tu définis
dans les Réglages :

- **Quota gratuit / jour** — le nombre de requêtes gratuites annoncé par le
  fournisseur
- **Marge de sécurité** — le nombre de requêtes à garder en réserve, jamais
  utilisées

L'extension calcule un plafond réel = `quota − marge`, et **arrête d'appeler
un agent dès que ce plafond est atteint dans la journée** (compteur stocké
localement, remis à zéro à minuit) — sans jamais faire la requête réseau. Le
popup affiche alors "Quota atteint" pour cet agent au lieu de "Aucun résultat".
Exemple : Sightengine annonce 500 requêtes gratuites/mois → mets une limite
journalière prudente (ex: 15/jour) et une marge de 2, l'extension s'arrêtera
à 13 pour ne jamais franchir le seuil payant.

⚠️ Chaque fournisseur a des règles de quota différentes (certains sont
mensuels, pas journaliers) — vérifie sur le site du fournisseur et ajuste la
valeur en conséquence ; ce système journalier est une protection simple, pas
une garantie absolue si le quota réel est mensuel.

## Installer l'extension en local

1. `chrome://extensions` → active le **Mode développeur**
2. **"Charger l'extension non empaquetée"** → sélectionne le dossier
   `ai-detector-extension/`
3. Clique sur l'icône de l'extension sur n'importe quel site (http/https) :
   le panneau apparaît en haut à droite de la page
4. Clique sur ⚙ dans le panneau pour ouvrir les **Réglages** et configurer
   tes agents

## Configurer l'agent image/vidéo intégré

1. Crée un compte gratuit chez un fournisseur de détection IA image/vidéo
   proposant une API `api_user` / `api_secret` (ex: recherche "AI generated
   image detection API free tier")
2. Récupère tes identifiants depuis son dashboard
3. Colle-les dans Réglages → "Agent image / vidéo", coche "Activer cet agent"
4. Le quota gratuit journalier et la marge de sécurité sont **pré-remplis
   automatiquement** (~100 requêtes/jour, estimation basée sur une offre
   gratuite courante de 2000 req/mois, 500/jour max, 5 unités par analyse
   IA) — ajuste ces deux valeurs si l'offre réelle de ton compte diffère

## Ajouter un provider personnalisé (Hive, isgen, AI or Not, Winston AI...)

Dans Réglages → "Ajouter un provider" :
- **Nom**, **Endpoint** (URL de l'API du fournisseur)
- **Header d'authentification** (ex: `Authorization`) et sa valeur
  (ex: `Bearer sk-...` ou `Token xxx`, selon le fournisseur)
- **Type de contenu analysé** : *Image / Vidéo* ou *Texte* — détermine si ce
  provider apparaît pour la sélection sur page / import de fichier, ou pour
  le bouton "Détecter un texte généré par IA"
- Pour un provider **Image / Vidéo** : **Mode d'envoi** (JSON avec l'URL du
  média, ou fichier importé en multipart)
- Pour un provider **Texte** : **Nom du paramètre texte (JSON)** — le nom du
  champ attendu par l'API pour recevoir le texte à analyser (ex: `text`,
  `content`, `input`... selon le fournisseur)
- **Quota gratuit / jour** et **marge de sécurité**

⚠️ Je n'ai pas codé en dur les formats exacts de Hive / isgen / AI or Not /
Winston AI / ZeroGPT car leurs contrats d'API (authentification, noms de
champs) varient et évoluent. L'extension **cherche automatiquement** un score
plausible (0 à 1) dans la réponse JSON, quel que soit son format exact — ça
fonctionne avec beaucoup d'APIs de détection, mais vérifie le résultat après
ajout et consulte la doc officielle du fournisseur si le score ne remonte pas.

## Structure du projet

```
manifest.json         → configuration Chrome (permissions, options_page,
                          web_accessible_resources pour panel.css)
scanner.js             → scan de métadonnées local (gratuit, sans clé)
providers.js           → adaptateur Sightengine + adaptateur générique REST
quota.js               → suivi d'usage quotidien par agent + callWithQuota()
content.js             → sélection rectangle sur la page + panneau flottant
                          injecté (Shadow DOM), déplaçable, fermeture par ✕
content.css            → styles de la sélection rectangle + toast
panel.css              → styles du panneau flottant (coins arrondis, ombre,
                          poignée de déplacement) — réutilisé aussi par
                          options.html pour une identité visuelle cohérente
background.js          → orchestre tous les agents + ouvre le panneau/les
                          Réglages sur demande du content script
options.html/.css/.js  → Réglages : clés API, quotas, providers personnalisés
icons/                  → icônes générées (16/32/48/128 px)
```

## Limites connues

- Aucun agent (métadonnées ou API) n'est fiable à 100% — des tests
  indépendants montrent des faux positifs et faux négatifs sur tous les
  détecteurs du marché. Le consensus multi-agents réduit le risque d'erreur
  mais ne l'élimine pas.
- Le mode "sélection sur la page" nécessite que le fichier soit accessible
  sans blocage CORS strict — sinon le tampon "Erreur" s'affiche pour cet
  agent, sans bloquer les autres.
- Le quota journalier est une approximation simple ; adapte la valeur selon
  que le quota réel du fournisseur est journalier, mensuel ou par crédit.
