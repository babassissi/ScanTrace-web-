// ScanTrace — content script (Version Figma combinée isolée, sécurisée avec écran de Consentement RGPD complet !)

(() => {
  // Sécurité anti-double injection : empêche les plantages de déclaration globale Chrome
  if (window.hasScanTraceInjected) return;
  window.hasScanTraceInjected = true;

  // ============================================================
  // Part 1 — Rectangle de sélection visuelle
  // ============================================================

  let overlayRoot = null;
  let selectionBox = null;
  let startX = 0;
  let startY = 0;
  let dragging = false;
  let expandedItemId = null;

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "PROV_TOGGLE_PANEL") {
      togglePanel();
      sendResponse({ ok: true });
    }
    return true;
  });

  function startSelectionMode() {
    if (overlayRoot) return;

    overlayRoot = document.createElement("div");
    overlayRoot.id = "prov-overlay-root";
    document.documentElement.appendChild(overlayRoot);

    selectionBox = document.createElement("div");
    selectionBox.id = "prov-selection-box";
    selectionBox.style.display = "none";
    document.documentElement.appendChild(selectionBox);

    showToast("Cliquez-glissez pour entourer une image ou une vidéo. Échap pour annuler.");

    overlayRoot.addEventListener("mousedown", onMouseDown);
    document.addEventListener("keydown", onKeyDown);
  }

  function onKeyDown(e) {
    if (e.key === "Escape") cleanupSelection();
  }

  function onMouseDown(e) {
    dragging = true;
    startX = e.clientX;
    startY = e.clientY;
    selectionBox.style.display = "block";
    updateBox(e.clientX, e.clientY);
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  }

  function onMouseMove(e) {
    if (!dragging) return;
    updateBox(e.clientX, e.clientY);
  }

  function updateBox(curX, curY) {
    const left = Math.min(startX, curX);
    const top = Math.min(startY, curY);
    selectionBox.style.left = left + "px";
    selectionBox.style.top = top + "px";
    selectionBox.style.width = Math.abs(curX - startX) + "px";
    selectionBox.style.height = Math.abs(curY - startY) + "px";
  }

  async function onMouseUp() {
    dragging = false;
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onMouseUp);

    const rect = selectionBox.getBoundingClientRect();
    cleanupSelection();

    if (rect.width < 10 || rect.height < 10) {
      showToast("Sélection trop petite.");
      setTimeout(removeToast, 2200);
      return;
    }

    showToast("Capture de la zone...");

    setTimeout(async () => {
      try {
        const response = await chrome.runtime.sendMessage({ type: "PROV_CAPTURE_TAB" });
        if (!response || !response.dataUrl) {
          showToast("Erreur lors de la capture d'écran.");
          setTimeout(removeToast, 2200);
          return;
        }
        const blob = await cropScreenshot(response.dataUrl, rect);
        removeToast();
        if (!panelHost) togglePanel();
        await handleCroppedBlob(blob);
      } catch (err) {
        console.error(err);
        showToast("Erreur lors du traitement visuel.");
        setTimeout(removeToast, 2200);
      }
    }, 80);
  }

  function cropScreenshot(dataUrl, rect) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const dpr = window.devicePixelRatio || 1;
        const sx = rect.left * dpr;
        const sy = rect.top * dpr;
        const sw = rect.width * dpr;
        const sh = rect.height * dpr;

        canvas.width = sw;
        canvas.height = sh;

        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);

        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else reject(new Error("Échec du crop canvas"));
        }, "image/jpeg", 0.9);
      };
      img.onerror = (err) => reject(err);
      img.src = dataUrl;
    });
  }

  async function handleCroppedBlob(blob) {
    const objectUrl = URL.createObjectURL(blob);
    const itemId = `${Date.now()}_crop`;
    const item = {
      id: itemId,
      type: "img",
      src: objectUrl,
      pageUrl: location.href,
      alt: "Zone capturée",
      status: "scanning",
      result: null,
    };

    const { provItems = [] } = await chrome.storage.local.get("provItems");
    const next = [item, ...provItems];
    await chrome.storage.local.set({ provItems: next });
    render(next);

    const fileBytes = Array.from(new Uint8Array(await blob.arrayBuffer()));
    const res = await chrome.runtime.sendMessage({
      type: "PROV_ANALYZE_ITEM",
      item: { type: "img", fileBytes, fileName: "capture.jpg", fileType: "image/jpeg", id: itemId },
    });
    const result = res && res.result ? res.result : { localMeta: null, apiResults: [], consensus: null };
    await updateItem(itemId, { status: "done", result });
  }

  function showToast(text) {
    removeToast();
    const t = document.createElement("div");
    t.id = "prov-toast";
    t.textContent = text;
    document.documentElement.appendChild(t);
  }
  function removeToast() {
    const t = document.getElementById("prov-toast");
    if (t) t.remove();
  }
  function cleanupSelection() {
    document.removeEventListener("keydown", onKeyDown);
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onMouseUp);
    if (overlayRoot) overlayRoot.remove();
    if (selectionBox) selectionBox.remove();
    overlayRoot = null;
    selectionBox = null;
    dragging = false;
  }

  // ============================================================
  // Part 2 — Structure et Actions du panneau Figma
  // ============================================================

  let panelHost = null;
  let shadow = null;

  function togglePanel() {
    if (panelHost) return;
    buildPanel();
  }

  function buildPanel() {
    panelHost = document.createElement("div");
    panelHost.id = "prov-panel-host";
    panelHost.style.cssText = "all: initial; position: fixed; top: 0; left: 0; z-index: 2147483647;";
    document.documentElement.appendChild(panelHost);
    shadow = panelHost.attachShadow({ mode: "open" });

    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL("panel.css");
    shadow.appendChild(link);

    const style = document.createElement("style");
    style.textContent = `
      .prov-video-warning {
        margin: 4px 6px 10px;
        padding: 8px 12px;
        background: rgba(245, 158, 11, 0.08) !important;
        border-left: 3px solid var(--warning) !important;
        border-radius: 8px;
        color: var(--paper-dim);
        font-size: 11px;
        line-height: 1.45;
      }
      .prov-consent-screen {
        display: flex;
        flex-direction: column;
        padding: 24px 18px;
        width: 100%;
        box-sizing: border-box;
      }
    `;
    shadow.appendChild(style);

    const panel = document.createElement("div");
    panel.className = "prov-panel";
    panel.innerHTML = `
      <!-- ÉCRAN 1 : FORMULAIRE DE CONSENTEMENT DE CONFIDENTIALITÉ COMPLET ET CONFORME (Masqué par défaut) -->
      <div id="provConsentScreen" class="prov-consent-screen" style="display: none;">
        <div class="prov-brand" style="display: flex; flex-direction: column; align-items: center; text-align: center; gap: 8px; margin-bottom: 18px; width: 100%;">
          <svg class="prov-logo-svg" width="36" height="36" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: var(--accent); filter: drop-shadow(0 0 8px var(--accent-ring));">
            <circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M19 19L15 15" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
            <text x="10" y="12" fill="currentColor" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="7" font-weight="900" text-anchor="middle" letter-spacing="-0.5">AI</text>
          </svg>
          <div>
            <h1 style="font-size: 20px;">ScanTrace</h1>
            <p class="prov-sub" style="font-size: 10px; margin-top: 4px;">AI Content Detector</p>
          </div>
        </div>
        
        <h2 style="font-size: 13.5px; font-weight: 800; text-align: center; margin: 0 0 8px; color: var(--paper);">Respect de votre vie privée</h2>
        <p style="font-size: 10.5px; line-height: 1.5; text-align: center; color: var(--paper-dim); margin: 0 0 16px;">
          Pour utiliser ScanTrace, veuillez valider nos conditions d'utilisation et de protection des données (RGPD). Vos clés d'API et l'historique de vos scans sont stockés de manière locale et sécurisée sur votre navigateur.
        </p>
        
        <div class="prov-policy-box" style="max-height: 140px; overflow-y: auto; background: rgba(0,0,0,0.15); border: 1px solid var(--line); border-radius: 8px; padding: 12px; font-size: 9.5px; line-height: 1.45; color: var(--paper-dim); margin-bottom: 18px; text-align: left; scrollbar-width: thin;">
          <strong style="color: var(--paper); font-size: 10px; display: block; margin-bottom: 8px; border-bottom: 1px solid var(--line); padding-bottom: 4px;">Politique de Confidentialité — ScanTrace</strong>
          <p style="margin: 0 0 10px 0;">La protection de vos données privées est au cœur de la philosophie de <strong>ScanTrace</strong>. Cette Politique de Confidentialité décrit comment l'extension gère, traite et protège vos informations.</p>
          
          <strong style="color: var(--paper); display: block; margin-bottom: 4px;">1. Quelles données collectons-nous ?</strong>
          <ul style="margin: 0 0 10px 0; padding-left: 14px;">
            <li style="margin-bottom: 4px;"><strong>Captures d'écran (activeTab) :</strong> La capture d'écran est traitée et recadrée entièrement en mémoire locale sur votre ordinateur (via un canvas). Aucun élément visuel n'est envoyé ou stocké sur un serveur distant.</li>
            <li style="margin-bottom: 4px;"><strong>Historique et réglages (chrome.storage.local) :</strong> Votre historique, clés d'API et quotas quotidiens restent stockés localement sur votre appareil. Vous pouvez vider l'historique et vos réglages à tout moment.</li>
            <li style="margin-bottom: 4px;"><strong>URLs et réseaux sociaux :</strong> Les requêtes vers les liens soumis s'exécutent en direct depuis votre navigateur (via oEmbed ou FixTweet) pour récupérer la légende textuelle et l'image d'illustration.</li>
          </ul>
          
          <strong style="color: var(--paper); display: block; margin-bottom: 4px;">2. Partage des données avec des tiers (APIs)</strong>
          <p style="margin: 0 0 10px 0;">Pour évaluer la probabilité qu'un contenu soit généré par IA, ScanTrace transmet les échantillons de textes ou de fichiers binaires à des services tiers d'analyse (Sightengine, Hugging Face, Sapling AI) en utilisant vos clés d'API configurées. Ce traitement est soumis à leurs chartes de confidentialité respectives.</p>
          
          <strong style="color: var(--paper); display: block; margin-bottom: 4px;">3. Permissions requises</strong>
          <ul style="margin: 0 0 10px 0; padding-left: 14px;">
            <li style="margin-bottom: 4px;"><code>activeTab</code> : Capturer visuellement l'écran à la demande expresse de l'utilisateur.</li>
            <li style="margin-bottom: 4px;"><code>scripting</code> : Injecter de façon sécurisée le panneau d'interface.</li>
            <li style="margin-bottom: 4px;"><code>storage</code> : Conserver localement vos préférences et clés d'API.</li>
          </ul>
          
          <strong style="color: var(--paper); display: block; margin-bottom: 4px;">4. Consentement</strong>
          <p style="margin: 0 0 10px 0;">En cliquant sur « Accepter et continuer », vous consentez à l'usage de ce stockage local pour exécuter l'extension ScanTrace.</p>
          
          <strong style="color: var(--paper); display: block; margin-bottom: 4px;">5. Nous contacter</strong>
          <p style="margin: 0;">Pour toute question concernant l'extension et la gestion de vos données : basile.ceyrac@protonmail.com</p>
        </div>
        
        <button id="provAcceptConsentBtn" class="prov-menu-item prov-menu-primary" style="justify-content: center; background: linear-gradient(135deg, var(--accent), var(--accent-hover)); color: #03050A; font-weight: 800; border: none; box-shadow: 0 4px 15px var(--accent-soft);">
          Accepter et continuer
        </button>
      </div>

      <!-- ÉCRAN 2 : INTERFACE PRINCIPALE DE L'EXTENSION (Masqué par défaut) -->
      <div id="provMainScreen" style="display: none; flex-direction: column; width: 100%;">
        <header class="prov-header" id="provDragHandle">
          <div class="prov-brand">
            <!-- Logo Loupe d'origine unifié de ScanTrace intégrant l'inscription "AI" en MAJUSCULES -->
            <svg class="prov-logo-svg" width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: var(--accent); filter: drop-shadow(0 0 8px var(--accent-ring)); flex-shrink: 0;">
              <circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M19 19L15 15" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
              <text x="10" y="12" fill="currentColor" font-family="-apple-system, BlinkMacSystemFont, sans-serif" font-size="7" font-weight="900" text-anchor="middle" letter-spacing="-0.5">AI</text>
            </svg>
            <div>
              <h1>ScanTrace</h1>
              <p class="prov-sub">AI Content Detector</p>
            </div>
          </div>
          <div class="prov-header-actions">
            <!-- Bouton de Réglages intégrant l'écrou géométrique de configuration à côté du texte -->
            <button class="prov-settings-btn" id="provSettingsBtn" title="Réglages" style="display: flex; align-items: center;">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 5px; color: currentColor;">
                <path d="M12 2l8.66 5v10L12 22l-8.66-5V7L12 2z" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/>
                <circle cx="12" cy="12" r="5" stroke="currentColor" stroke-width="2"/>
                <circle cx="12" cy="12" r="2" fill="currentColor"/>
              </svg>
              Réglages
            </button>
            <button class="prov-close-btn" id="provCloseBtn" title="Fermer">✕</button>
          </div>
        </header>
        <div class="prov-panel-body">
          <main class="prov-main">
            <nav class="prov-menu">
              <button id="provSelectBtn" class="prov-menu-item">
                <span class="prov-menu-icon">
                  <svg width="14" height="14" viewBox="0 0 12 12" fill="none"><rect x="1" y="1" width="3.5" height="3.5" rx="0.8" stroke="currentColor" stroke-width="1.2"/><rect x="7.5" y="1" width="3.5" height="3.5" rx="0.8" stroke="currentColor" stroke-width="1.2"/><rect x="1" y="7.5" width="3.5" height="3.5" rx="0.8" stroke="currentColor" stroke-width="1.2"/><path d="M7.5 7.5h4M9.5 7.5v4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
                </span>
                <!-- Libellé de précision corrigé pour l'analyse à l'écran -->
                <span class="prov-menu-text"><strong>Sélectionner sur la page</strong><small>Sélectionner une zone à l'écran</small></span>
                <span class="prov-menu-arrow">❯</span>
              </button>
              <button id="provUploadImageBtn" class="prov-menu-item">
                <span class="prov-menu-icon">
                  <svg width="14" height="14" viewBox="0 0 12 12" fill="none"><path d="M6 8V2M3.5 4.5L6 2l2.5 2.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.5 9.5h9" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
                </span>
                <!-- Libellé de précision corrigé pour l'import d'image locale -->
                <span class="prov-menu-text"><strong>Analyser une image locale</strong><small>Importer une image (JPG, PNG, WebP…)</small></span>
                <span class="prov-menu-arrow">❯</span>
              </button>
              <button id="provUploadVideoBtn" class="prov-menu-item">
                <span class="prov-menu-icon">⇪</span>
                <!-- Libellé de précision corrigé pour l'import de vidéo locale -->
                <span class="prov-menu-text"><strong>Analyser une vidéo locale</strong><small>Importer un fichier vidéo (MP4, WebM…)</small></span>
                <span class="prov-menu-arrow">❯</span>
              </button>
              <div id="provVideoWarning" class="prov-video-warning" style="display: none;">
                ⚠️ <strong>Remarque :</strong> L'étalonnage de couleurs sur une vidéo peut altérer sa signature d'origine.
              </div>
              <button id="provLinkBtn" class="prov-menu-item">
                <span class="prov-menu-icon">
                  <svg width="14" height="14" viewBox="0 0 12 12" fill="none"><path d="M5 7a2.5 2.5 0 0 0 3.5.3l1.3-1.3A2.5 2.5 0 0 0 6.3 2.5L5.5 3.3" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/><path d="M7 5a2.5 2.5 0 0 0-3.5-.3L2.2 6A2.5 2.5 0 0 0 5.7 9.5L6.5 8.7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
                </span>
                <span class="prov-menu-text"><strong>Analyse depuis un lien</strong><small>Coller l'URL directe d'un média</small></span>
                <span class="prov-menu-arrow">❯</span>
              </button>
              <button id="provPostBtn" class="prov-menu-item">
                <span class="prov-menu-icon">
                  <svg width="14" height="14" viewBox="0 0 12 12" fill="none"><rect x="1.5" y="1.5" width="9" height="9" rx="2" stroke="currentColor" stroke-width="1.2"/><circle cx="4" cy="4" r="0.9" fill="currentColor"/><path d="M1.5 8.5l2.5-2.5 2 2L8.5 5.5l2 2.5" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </span>
                <span class="prov-menu-text"><strong>Analyse d'un Post complet</strong><small>Lien Instagram, X, TikTok, YouTube</small></span>
                <span class="prov-menu-arrow">❯</span>
              </button>
              <button id="provTextBtn" class="prov-menu-item">
                <span class="prov-menu-icon">T</span>
                <span class="prov-menu-text"><strong>Détecter un texte IA</strong><small>Coller un texte à évaluer</small></span>
                <span class="prov-menu-arrow">❯</span>
              </button>
            </nav>
            <div id="provLinkPanel" class="prov-text-panel" hidden>
              <input type="url" id="provLinkInput" class="prov-textarea" placeholder="Colle le lien direct de l'image ou de la vidéo..." />
              <div class="prov-link-type-row">
                <select id="provLinkType" class="prov-textarea">
                  <option value="img">Image</option>
                  <option value="video">Vidéo</option>
                </select>
                <button id="provLinkSubmit" class="prov-menu-item prov-menu-primary prov-text-submit">
                  <span class="prov-menu-text"><strong>Analyser ce lien</strong></span>
                </button>
              </div>
            </div>
            <div id="provPostPanel" class="prov-text-panel" hidden>
              <input type="url" id="provPostInput" class="prov-textarea" placeholder="Colle le lien Instagram, X, TikTok ou YouTube..." />
              <button id="provPostSubmit" class="prov-menu-item prov-menu-primary prov-text-submit" style="justify-content: center;">
                <span class="prov-menu-text"><strong>Analyser ce post complet</strong></span>
              </button>
            </div>
            <div id="provTextPanel" class="prov-text-panel" hidden>
              <textarea id="provTextArea" class="prov-textarea" placeholder="Colle ici le texte à analyser…" rows="5"></textarea>
              <button id="provTextSubmit" class="prov-menu-item prov-menu-primary prov-text-submit">
                <span class="prov-menu-text"><strong>Analyser ce texte</strong></span>
              </button>
            </div>
            <input type="file" id="provFileImage" accept="image/*" hidden />
            <input type="file" id="provFileVideo" accept="video/*" hidden />
            <p class="prov-hint">Déplace le panneau par son en-tête. Il reste ouvert tant que tu ne cliques pas sur ✕.</p>
            <div id="provEmptyState" class="prov-empty">
              <div class="prov-empty-glyph">◌</div>
              <p>Aucun contenu sélectionné pour le moment.</p>
            </div>
            <ul id="provItemList" class="prov-list"></ul>
          </main>
          <footer class="prov-footer">
            <p>Analyse multi-agents indicative. Aucun outil n'est fiable à 100%.</p>
            <div class="prov-footer-controls" style="display: flex; align-items: center; gap: 8px;">
              <!-- Interrupteur minimaliste (Toggle Switch) pour le mode Clair Sable -->
              <label class="prov-theme-switch" title="Changer de thème">
                <input type="checkbox" id="provThemeToggle" />
                <span class="prov-theme-slider"></span>
              </label>
              <div class="prov-footer-version">v0.1.0</div>
            </div>
          </footer>
        </div>
      </div>
    `;
    shadow.appendChild(panel);

    wirePanel(panel);
    makeDraggable(panel, panel.querySelector("#provDragHandle"));
  }

  function wirePanel(panel) {
    const consentScreen = panel.querySelector("#provConsentScreen");
    const mainScreen = panel.querySelector("#provMainScreen");
    const acceptConsentBtn = panel.querySelector("#provAcceptConsentBtn");

    // Étape 1 : Vérification asynchrone du consentement RGPD
    chrome.storage.local.get("provConsentAccepted", (data) => {
      if (data && data.provConsentAccepted === true) {
        mainScreen.style.display = "flex";
        loadItems(); // Charge l'historique uniquement si consenti
      } else {
        consentScreen.style.display = "flex";
      }
    });

    // Écouteur d'acceptation du consentement RGPD
    acceptConsentBtn.addEventListener("click", () => {
      chrome.storage.local.set({ provConsentAccepted: true }, () => {
        consentScreen.style.display = "none";
        mainScreen.style.display = "flex";
        loadItems(); // Initie l'historique de scan
      });
    });

    panel.querySelector("#provCloseBtn").addEventListener("click", closePanel);
    panel.querySelector("#provSettingsBtn").addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "PROV_OPEN_OPTIONS" });
    });
    panel.querySelector("#provSelectBtn").addEventListener("click", () => {
      startSelectionMode();
    });

    const fileImage = panel.querySelector("#provFileImage");
    const fileVideo = panel.querySelector("#provFileVideo");
    panel.querySelector("#provUploadImageBtn").addEventListener("click", () => fileImage.click());
    
    const videoWarning = panel.querySelector("#provVideoWarning");
    panel.querySelector("#provUploadVideoBtn").addEventListener("click", () => {
      videoWarning.style.display = videoWarning.style.display === "none" ? "block" : "none";
      fileVideo.click();
    });

    fileImage.addEventListener("change", (e) => handleLocalFile(e.target.files[0], "img"));
    fileVideo.addEventListener("change", (e) => handleLocalFile(e.target.files[0], "video"));

    const textPanel = panel.querySelector("#provTextPanel");
    panel.querySelector("#provTextBtn").addEventListener("click", () => {
      textPanel.hidden = !textPanel.hidden;
    });
    panel.querySelector("#provTextSubmit").addEventListener("click", () => {
      const ta = panel.querySelector("#provTextArea");
      const text = ta.value.trim();
      if (!text) return;
      handleTextAnalysis(text);
      ta.value = "";
      textPanel.hidden = true;
    });

    const linkPanel = panel.querySelector("#provLinkPanel");
    panel.querySelector("#provLinkBtn").addEventListener("click", () => {
      linkPanel.hidden = !linkPanel.hidden;
    });
    panel.querySelector("#provLinkSubmit").addEventListener("click", () => {
      const inputEl = panel.querySelector("#provLinkInput");
      const typeEl = panel.querySelector("#provLinkType");
      const url = inputEl.value.trim();
      const type = typeEl.value;
      if (!url) return;
      handleLinkAnalysis(url, type);
      inputEl.value = "";
      linkPanel.hidden = true;
    });

    const postPanel = panel.querySelector("#provPostPanel");
    panel.querySelector("#provPostBtn").addEventListener("click", () => {
      postPanel.hidden = !postPanel.hidden;
    });
    panel.querySelector("#provPostSubmit").addEventListener("click", () => {
      const inputEl = panel.querySelector("#provPostInput");
      const url = inputEl.value.trim();
      if (!url) return;
      handlePostLinkAnalysis(url);
      inputEl.value = "";
      postPanel.hidden = true;
    });

    // Écouteur pour l'interrupteur de changement de thème
    const themeToggle = panel.querySelector("#provThemeToggle");
    const panelContainer = panel;

    // Persistance : Chargement du thème en local
    chrome.storage.local.get("provThemeMode", (data) => {
      if (data && data.provThemeMode === "light") {
        themeToggle.checked = true;
        panelContainer.classList.add("prov-light-mode");
      }
    });

    themeToggle.addEventListener("change", () => {
      if (themeToggle.checked) {
        panelContainer.classList.add("prov-light-mode");
        chrome.storage.local.set({ provThemeMode: "light" });
      } else {
        panelContainer.classList.remove("prov-light-mode");
        chrome.storage.local.set({ provThemeMode: "dark" });
      }
    });
  }

  function closePanel() {
    if (!panelHost) return;
    panelHost.remove();
    panelHost = null;
    shadow = null;
  }

  function makeDraggable(panel, handle) {
    let offsetX = 0;
    let offsetY = 0;
    let moving = false;

    handle.addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) return;
      moving = true;
      const rect = panel.getBoundingClientRect();
      offsetX = e.clientX - rect.left;
      offsetY = e.clientY - rect.top;
      panel.style.right = "auto";
      document.addEventListener("mousemove", onDragMove);
      document.addEventListener("mouseup", onDragEnd);
      e.preventDefault();
    });

    function onDragMove(e) {
      if (!moving) return;
      const maxLeft = window.innerWidth - panel.offsetWidth - 4;
      const maxTop = window.innerHeight - 40;
      const left = Math.min(Math.max(4, e.clientX - offsetX), maxLeft);
      const top = Math.min(Math.max(4, e.clientY - offsetY), maxTop);
      panel.style.left = left + "px";
      panel.style.top = top + "px";
    }

    function onDragEnd() {
      moving = false;
      document.removeEventListener("mousemove", onDragMove);
      document.removeEventListener("mouseup", onDragEnd);
    }
  }

  async function handleLocalFile(file, type) {
    if (!file) return;

    const objectUrl = URL.createObjectURL(file);
    const item = {
      id: `${Date.now()}_local`,
      type,
      src: objectUrl,
      pageUrl: "fichier local",
      alt: file.name,
      status: "scanning",
      result: null,
    };

    const { provItems = [] } = await chrome.storage.local.get("provItems");
    const next = [item, ...provItems];
    await chrome.storage.local.set({ provItems: next });
    render(next);

    let res;
    if (type === "video") {
      const samples = await extractVideoSamples(file);
      res = await chrome.runtime.sendMessage({ type: "PROV_ANALYZE_VIDEO_SAMPLES", samples, itemId: item.id });
    } else {
      const fileBytes = Array.from(new Uint8Array(await file.arrayBuffer()));
      res = await chrome.runtime.sendMessage({
        type: "PROV_ANALYZE_ITEM",
        item: { type, fileBytes, fileName: file.name, fileType: file.type, id: item.id },
      });
    }
    const result = res && res.result ? res.result : { localMeta: null, apiResults: [], consensus: null };
    await updateItem(item.id, { status: "done", result });
  }

  async function extractVideoSamples(fileOrUrl) {
    const url = typeof fileOrUrl === "string" ? fileOrUrl : URL.createObjectURL(fileOrUrl);
    const video = document.createElement("video");
    video.muted = true;
    video.preload = "auto";
    video.src = url;
    
    if (typeof fileOrUrl === "string") {
      video.crossOrigin = "anonymous";
    }

    await new Promise((resolve, reject) => {
      video.addEventListener("loadedmetadata", resolve, { once: true });
      video.addEventListener("error", () => reject(new Error("Impossible de lire cette vidéo.")), { once: true });
    });

    const duration = Number.isFinite(video.duration) ? video.duration : 10;
    const timestamps = [...new Set([Math.min(2, duration), Math.min(8, duration)].filter((time) => time >= 0))];
    const canvas = document.createElement("canvas");
    const samples = [];

    for (const second of timestamps) {
      await new Promise((resolve, reject) => {
        video.addEventListener("seeked", resolve, { once: true });
        video.addEventListener("error", () => reject(new Error("Impossible d’extraire les images.")), { once: true });
        video.currentTime = second;
      });
      const scale = Math.min(1, 960 / video.videoWidth);
      canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
      canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
      canvas.getContext("2d").drawImage(video, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.82));
      if (!blob) continue;
      samples.push({ second, bytes: Array.from(new Uint8Array(await blob.arrayBuffer())) });
    }
    
    if (typeof fileOrUrl !== "string") {
      URL.revokeObjectURL(url);
    }
    
    if (!samples.length) throw new Error("Aucune image n'a pu être extraite.");
    return samples;
  }

  async function handleLinkAnalysis(url, type) {
    showToast("Résolution du lien...");
    
    let targetUrl = url.trim();
    if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
      targetUrl = "https://" + targetUrl;
    }

    let finalUrl = targetUrl;
    let finalType = type;

    const isSocialWebpage = targetUrl.includes("instagram.com") || 
                            targetUrl.includes("tiktok.com") || 
                            targetUrl.includes("x.com") || 
                            targetUrl.includes("twitter.com") || 
                            targetUrl.includes("facebook.com") || 
                            targetUrl.includes("youtu.be") || 
                            targetUrl.includes("youtube.com/watch") ||
                            targetUrl.includes("youtube.com/shorts");

    if (isSocialWebpage && finalType !== "post") {
      finalType = "img";
    }

    try {
      const res = await chrome.runtime.sendMessage({ type: "PROV_RESOLVE_URL", url: targetUrl });
      if (res && res.resolvedUrl && res.resolvedUrl !== targetUrl) {
        finalUrl = res.resolvedUrl;
        if (finalType !== "post") {
          finalType = "img"; 
        }
      }
    } catch (err) {
      console.warn("[Provenance] Impossible de résoudre le lien:", err);
    }

    removeToast();

    const item = {
      id: `${Date.now()}_link`,
      type: finalType,
      src: finalUrl,
      pageUrl: url, 
      alt: "Lien collé",
      status: "scanning",
      result: null,
    };

    const { provItems = [] } = await chrome.storage.local.get("provItems");
    const next = [item, ...provItems];
    await chrome.storage.local.set({ provItems: next });
    render(next);

    await analyzeRemoteAndUpdate(item);
  }

  async function handlePostLinkAnalysis(url) {
    showToast("Résolution du post complet...");
    
    let targetUrl = url.trim();
    if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
      targetUrl = "https://" + targetUrl;
    }

    let finalUrl = targetUrl;

    try {
      const res = await chrome.runtime.sendMessage({ type: "PROV_RESOLVE_URL", url: targetUrl });
      if (res && res.resolvedUrl) {
        finalUrl = res.resolvedUrl;
      }
    } catch (err) {
      console.warn("[Provenance] Impossible de résoudre le lien:", err);
    }

    removeToast();

    const item = {
      id: `${Date.now()}_post_link`,
      type: "post", 
      src: finalUrl,
      pageUrl: url,
      alt: "Post complet",
      status: "scanning",
      result: null,
    };

    const { provItems = [] } = await chrome.storage.local.get("provItems");
    const next = [item, ...provItems];
    await chrome.storage.local.set({ provItems: next });
    render(next);

    await analyzeRemoteAndUpdate(item);
  }

  async function handleTextAnalysis(text) {
    const item = {
      id: `${Date.now()}_text`,
      type: "text",
      src: text,
      pageUrl: "texte collé",
      alt: "",
      status: "scanning",
      result: null,
    };

    const { provItems = [] } = await chrome.storage.local.get("provItems");
    const next = [item, ...provItems];
    await chrome.storage.local.set({ provItems: next });
    render(next);

    const res = await chrome.runtime.sendMessage({ type: "PROV_ANALYZE_TEXT", text, itemId: item.id });
    const result = res && res.result ? res.result : { localMeta: null, apiResults: [], consensus: null };
    await updateItem(item.id, { status: "done", result });
  }

  async function loadItems() {
    const { provItems = [] } = await chrome.storage.local.get("provItems");
    render(provItems);
  }

  async function analyzeRemoteAndUpdate(item) {
    await updateItem(item.id, { status: "scanning" });
    try {
      let res;
      if (item.type === "video") {
        const samples = await extractVideoSamples(item.src);
        res = await chrome.runtime.sendMessage({ type: "PROV_ANALYZE_VIDEO_SAMPLES", samples });
      } else {
        res = await chrome.runtime.sendMessage({ type: "PROV_ANALYZE_ITEM", item });
      }
      
      if (!res?.ok) throw new Error(res?.error || "L’analyse n’a pas renvoyé de résultat.");
      
      const { provItems = [] } = await chrome.storage.local.get("provItems");
      const current = provItems.find((it) => it.id === item.id);
      if (current && current.status === "cancelled") return;

      await updateItem(item.id, { status: "done", result: res.result });
    } catch (error) {
      const { provItems = [] } = await chrome.storage.local.get("provItems");
      const current = provItems.find((it) => it.id === item.id);
      if (current && current.status === "cancelled") return;

      await updateItem(item.id, {
        status: "done",
        result: { localMeta: null, apiResults: [{ provider: "Agent image/vidéo", ok: false, score: null, label: "Erreur", detail: String(error) }], consensus: null },
      });
    }
  }

  async function abortAnalysis(itemId) {
    await updateItem(itemId, { status: "cancelled" });
    await chrome.runtime.sendMessage({ type: "PROV_ABORT_ANALYSIS", itemId });
  }

  async function updateItem(id, patch) {
    const { provItems = [] } = await chrome.storage.local.get("provItems");
    const next = provItems.map((it) => (it.id === id ? { ...it, ...patch } : it));
    await chrome.storage.local.set({ provItems: next });
    render(next);
  }

  function render(items) {
    if (!shadow) return;
    const itemList = shadow.getElementById("provItemList");
    const emptyState = shadow.getElementById("provEmptyState");
    if (!itemList || !emptyState) return;

    itemList.innerHTML = "";
    emptyState.style.display = items.length === 0 ? "block" : "none";

    for (const item of items) {
      const li = document.createElement("li");
      li.className = "prov-item";

      const itemHeader = document.createElement("div");
      itemHeader.className = "prov-item-header";
      itemHeader.addEventListener("click", () => {
        expandedItemId = expandedItemId === item.id ? null : item.id;
        render(items);
      });

      const thumbWrap = document.createElement("div");
      thumbWrap.className = "prov-thumb-wrap";
      if (item.type === "text") {
        thumbWrap.classList.add("prov-thumb-text");
        thumbWrap.textContent = "T";
      } else {
        const media = document.createElement(item.type === "video" ? "video" : "img");
        media.src = item.src;
        if (item.type === "video") media.muted = true;
        thumbWrap.appendChild(media);

        const bTop = document.createElement("div");
        bTop.className = "prov-thumb-bracket prov-thumb-bracket-top";
        const bBottom = document.createElement("div");
        bBottom.className = "prov-thumb-bracket prov-thumb-bracket-bottom";
        thumbWrap.appendChild(bTop);
        thumbWrap.appendChild(bBottom);
      }

      const body = document.createElement("div");
      body.className = "prov-item-body";

      const metaRow = document.createElement("div");
      metaRow.className = "prov-item-meta-row";

      const type = document.createElement("p");
      type.className = "prov-item-type";
      type.textContent = item.type === "video" ? "Vidéo" : item.type === "text" ? "Texte" : item.type === "post" ? "Publication" : "Image";

      const src = document.createElement("p");
      src.className = "prov-src";
      src.textContent = item.type === "text" ? textPreview(item.src) : shortenUrl(item.src);
      src.title = item.src;

      metaRow.appendChild(type);
      metaRow.appendChild(src);

      const titleEl = document.createElement("h4");
      titleEl.className = "prov-item-title";
      titleEl.textContent = item.alt || (item.type === "text" ? "Texte soumis" : "Fichier ou lien");

      body.appendChild(metaRow);
      body.appendChild(titleEl);
      body.appendChild(buildVerdictBlock(item));

      itemHeader.appendChild(thumbWrap);
      itemHeader.appendChild(body);
      li.appendChild(itemHeader);

      if (expandedItemId === item.id && item.result) {
        const accordion = document.createElement("div");
        accordion.className = "prov-accordion";

        const { localMeta, apiResults = [] } = item.result;
        const strongLocalHit = localMeta && (localMeta.verdict === "credentials" || localMeta.verdict === "ai_signature");

        if (localMeta) {
          accordion.appendChild(buildAgentRow("Métadonnées locales", localMeta.detail, strongLocalHit ? "hit" : "flat"));
        }
        for (const r of apiResults) {
          const kind = r.skipped ? "quota" : !r.ok ? "err" : r.score >= 0.7 ? "hit" : r.score >= 0.35 ? "mid" : "flat";
          accordion.appendChild(buildAgentRow(`${r.provider} — ${r.label}`, r.detail, kind));
        }

        li.appendChild(accordion);
      }

      itemList.appendChild(li);
    }

    shadow.querySelectorAll(".prov-cancel-analysis-btn").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const itemId = btn.dataset.itemId;
        await abortAnalysis(itemId);
      });
    });
  }

  function buildVerdictBlock(item) {
    const wrap = document.createElement("div");

    if (item.status === "pending" || item.status === "scanning") {
      const container = document.createElement("div");
      container.className = "prov-scanning-container";

      const stamp = document.createElement("span");
      stamp.className = "prov-stamp scanning";
      stamp.innerHTML = `<span class="prov-spin"></span> Analyse…`;
      container.appendChild(stamp);

      const cancelBtn = document.createElement("button");
      cancelBtn.className = "prov-cancel-analysis-btn";
      cancelBtn.dataset.itemId = item.id;
      cancelBtn.innerHTML = "✕ Arrêter";
      container.appendChild(cancelBtn);

      wrap.appendChild(container);
      return wrap;
    }

    if (item.status === "cancelled") {
      const stamp = document.createElement("span");
      stamp.className = "prov-stamp error";
      stamp.textContent = "Analyse annulée";
      wrap.appendChild(stamp);
      return wrap;
    }

    const { localMeta, apiResults = [], consensus, consensusText, consensusImage } = item.result || {};
    const strongLocalHit = localMeta && (localMeta.verdict === "credentials" || localMeta.verdict === "ai_signature");

    const vrRow = document.createElement("div");
    vrRow.className = "prov-verdict-row";

    if (item.type === "post") {
      if (!consensusText && !consensusImage) {
        const stamp = document.createElement("span");
        stamp.className = "prov-stamp error";
        stamp.textContent = "Analyse indisponible";
        vrRow.appendChild(stamp);
      } else {
        if (consensusText) {
          const cls = consensusText.avgScore >= 0.7 ? "ai_signature" : consensusText.avgScore >= 0.35 ? "no_signal" : "credentials_ok";
          const stamp = document.createElement("span");
          stamp.className = `prov-stamp ${cls}`;
          stamp.textContent = `Texte : ${consensusText.label} · ${(consensusText.avgScore * 100).toFixed(0)}%`; 
          vrRow.appendChild(stamp);
        }
        
        if (consensusImage) {
          const cls = consensusImage.avgScore >= 0.7 ? "ai_signature" : consensusImage.avgScore >= 0.35 ? "no_signal" : "credentials_ok";
          const stamp = document.createElement("span");
          stamp.className = `prov-stamp ${cls}`;
          const labelPrefix = apiResults.some(r => r.provider.includes("Vidéo")) ? "Vidéo" : "Image";
          stamp.textContent = `${labelPrefix} : ${consensusImage.label} · ${(consensusImage.avgScore * 100).toFixed(0)}%`; 
          vrRow.appendChild(stamp);
        }
      }
    } else {
      const stamp = document.createElement("span");
      if (strongLocalHit) {
        stamp.className = "prov-stamp credentials";
        stamp.textContent = "Preuve trouvée (métadonnées)";
      } else if (consensus) {
        const cls = consensus.avgScore >= 0.7 ? "ai_signature" : consensus.avgScore >= 0.35 ? "no_signal" : "credentials_ok";
        stamp.className = `prov-stamp ${cls}`;
        stamp.textContent = `${consensus.label}`;
      } else if (apiResults.length === 0) {
        stamp.className = "prov-stamp no_signal";
        stamp.textContent = "Aucun agent configuré";
      } else {
        stamp.className = "prov-stamp error";
        stamp.textContent = "Aucun résultat exploitable";
      }
      vrRow.appendChild(stamp);

      if (consensus) {
        const scoreT = document.createElement("span");
        scoreT.className = "prov-score-text";
        scoreT.textContent = `Score : ${(consensus.avgScore * 100).toFixed(0)}%`;
        vrRow.appendChild(scoreT);
      }
    }

    wrap.appendChild(vrRow);
    return wrap;
  }

  function buildAgentRow(title, detail, kind) {
    const li = document.createElement("div");
    li.className = `prov-agent-row prov-agent-${kind}`;
    const t = document.createElement("strong");
    t.textContent = title;
    const d = document.createElement("span");
    d.textContent = detail;
    li.appendChild(t);
    li.appendChild(d);
    return li;
  }

  function textPreview(text) {
    const clean = text.replace(/\s+/g, " ").trim();
    return clean.length > 30 ? clean.slice(0, 30) + "…" : clean;
  }

  function shortenUrl(url) {
    try {
      if (url.startsWith("blob:")) return "fichier local";
      const u = new URL(url);
      const file = u.pathname.split("/").pop() || u.hostname;
      return u.hostname + "/…/" + file;
    } catch {
      return url;
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.provItems) render(changes.provItems.newValue || []);
  });
})();