// Provenance — providers.js
// Adapters that call third-party AI-content-detection APIs and normalize
// their response into { ok, score (0..1 | null), label, detail }.
// Loaded via importScripts() in background.js.

(function (root) {
  // ---- generic helper: find a plausible 0..1 "AI score" anywhere in a
  // nested JSON response, without needing to know the exact schema. ----
  const SCORE_KEY_HINTS = [
    "ai_generated",
    "ai_score",
    "ai_probability",
    "fake_probability",
    "fake_score",
    "synthetic_score",
    "deepfake_score",
    "probability",
    "score",
    "confidence",
  ];

  function findScoreRecursive(obj, depth = 0) {
    if (depth > 6 || obj === null || obj === undefined) return null;
    if (typeof obj === "number") return null; // handled by caller via key match
    if (typeof obj !== "object") return null;

    for (const key of Object.keys(obj)) {
      const val = obj[key];
      const keyLower = key.toLowerCase();
      if (typeof val === "number" && val >= 0 && val <= 1 && SCORE_KEY_HINTS.some((h) => keyLower.includes(h))) {
        return val;
      }
    }
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (val && typeof val === "object") {
        const found = findScoreRecursive(val, depth + 1);
        if (found !== null) return found;
      }
    }
    return null;
  }

  function scoreToLabel(score) {
    if (score === null) return "Score indisponible";
    if (score >= 0.7) return "Probablement généré par IA";
    if (score >= 0.35) return "Incertain";
    return "Probablement authentique";
  }

  // ---------------------------------------------------------------------
  // Sightengine — https://sightengine.com/docs/ai-generated-image-detection
  // Free tier available. Needs api_user + api_secret from the user's account.
  // ---------------------------------------------------------------------
  async function sightengineAnalyze({ src, file, mediaType, creds }) {
    if (!creds || !creds.apiUser || !creds.apiSecret) {
      return { provider: "Agent image/vidéo", ok: false, score: null, label: "Non configuré", detail: "Ajoute tes clés API dans les Réglages." };
    }

    const endpoint =
      mediaType === "video"
        ? "https://api.sightengine.com/1.0/video/check-sync.json"
        : "https://api.sightengine.com/1.0/check.json";

    const form = new FormData();
    form.append("models", "genai");
    form.append("api_user", creds.apiUser);
    form.append("api_secret", creds.apiSecret);

    if (file) {
      form.append("media", file, file.name || "media");
    } else if (src) {
      form.append("url", src);
    } else {
      return { provider: "Agent image/vidéo", ok: false, score: null, label: "Erreur", detail: "Aucune source à analyser." };
    }

    try {
      const res = await fetch(endpoint, { method: "POST", body: form });
      const json = await res.json();
      if (json.status === "failure") {
        return {
          provider: "Agent image/vidéo",
          ok: false,
          score: null,
          label: "Erreur API",
          detail: json.error?.message || "Requête refusée par le fournisseur.",
        };
      }
      const score = findScoreRecursive(json);
      return {
        provider: "Agent image/vidéo",
        ok: true,
        score,
        label: scoreToLabel(score),
        detail: score !== null ? `Score renvoyé par le fournisseur : ${(score * 100).toFixed(1)}%.` : "Réponse reçue mais aucun score exploitable trouvé.",
      };
    } catch (err) {
      return { provider: "Agent image/vidéo", ok: false, score: null, label: "Erreur réseau", detail: String(err) };
    }
  }

  // ---------------------------------------------------------------------
  // Generic custom provider — for any API the user configures manually
  // in the Réglages page (name, endpoint, auth header, body mode).
  // We don't assume a response schema: we search recursively for a
  // plausible score field.
  // ---------------------------------------------------------------------
  async function customProviderAnalyze({ src, file, mediaType }, provider) {
    try {
      const headers = {};
      if (provider.authHeaderName && provider.authHeaderValue) {
        headers[provider.authHeaderName] = provider.authHeaderValue;
      }

      let body;
      if (provider.bodyMode === "multipart_file") {
        if (!file) {
          return { provider: provider.name, ok: false, score: null, label: "Ignoré", detail: "Ce provider ne gère que les fichiers importés localement." };
        }
        const form = new FormData();
        form.append(provider.fileFieldName || "file", file, file.name || "media");
        body = form;
      } else {
        headers["Content-Type"] = "application/json";
        body = JSON.stringify({ [provider.urlFieldName || "url"]: src });
      }

      const res = await fetch(provider.endpoint, { method: "POST", headers, body });
      const json = await res.json();
      const score = findScoreRecursive(json);
      return {
        provider: provider.name,
        ok: true,
        score,
        label: scoreToLabel(score),
        detail: score !== null ? `Score renvoyé : ${(score * 100).toFixed(1)}%.` : "Réponse reçue mais aucun score exploitable trouvé (vérifie la config dans les Réglages).",
      };
    } catch (err) {
      return { provider: provider.name, ok: false, score: null, label: "Erreur réseau", detail: String(err) };
    }
  }

  // ---------------------------------------------------------------------
  // Text provider — for APIs specialised in AI-generated text detection
  // (GPTZero, Originality.ai, Winston AI, Copyleaks, ZeroGPT...). The user
  // configures these the same way as image/video custom providers, but
  // marked as "Texte" so the panel routes plain text to them instead of
  // a file/URL.
  // ---------------------------------------------------------------------
  async function customProviderAnalyzeText({ text }, provider) {
    if (!text || !text.trim()) {
      return { provider: provider.name, ok: false, score: null, label: "Erreur", detail: "Aucun texte à analyser." };
    }
    try {
      const headers = { "Content-Type": "application/json" };
      if (provider.authHeaderName && provider.authHeaderValue) {
        headers[provider.authHeaderName] = provider.authHeaderValue;
      }
      const body = JSON.stringify({ [provider.textFieldName || "text"]: text });

      const res = await fetch(provider.endpoint, { method: "POST", headers, body });
      const json = await res.json();
      const score = findScoreRecursive(json);
      return {
        provider: provider.name,
        ok: true,
        score,
        label: scoreToLabel(score),
        detail: score !== null ? `Score renvoyé : ${(score * 100).toFixed(1)}%.` : "Réponse reçue mais aucun score exploitable trouvé (vérifie la config dans les Réglages).",
      };
    } catch (err) {
      return { provider: provider.name, ok: false, score: null, label: "Erreur réseau", detail: String(err) };
    }
  }

  function base64Url(bytes) {
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  async function saplingToken(publicKey, privateKey) {
    const encoder = new TextEncoder();
    const header = base64Url(encoder.encode(JSON.stringify({ alg: "HS256", typ: "JWT" })));
    const now = Math.floor(Date.now() / 1000);
    const payload = base64Url(encoder.encode(JSON.stringify({ sub: publicKey, iat: now, exp: now + 3600 })));
    const signingInput = `${header}.${payload}`;
    const signingKey = await crypto.subtle.importKey("raw", encoder.encode(privateKey), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const signature = await crypto.subtle.sign("HMAC", signingKey, encoder.encode(signingInput));
    return `${signingInput}.${base64Url(new Uint8Array(signature))}`;
  }

  async function saplingAnalyzeText({ text, publicKey, privateKey }) {
    if (!text || !text.trim()) {
      return { provider: "Agent texte", ok: false, score: null, label: "Erreur", detail: "Aucun texte à analyser." };
    }
    if (!publicKey || !privateKey) {
      return { provider: "Agent texte", ok: false, score: null, label: "Non configuré", detail: "Ajoute tes clés publique et privée Sapling dans les Réglages." };
    }
    try {
      const token = await saplingToken(publicKey, privateKey);
      const res = await fetch("https://api.sapling.ai/api/v1/aidetect", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ text, sent_scores: false }),
      });
      const json = await res.json();
      if (!res.ok) {
        return { provider: "Agent texte", ok: false, score: null, label: "Erreur API", detail: json.error || json.message || "Requête refusée par Sapling." };
      }
      const score = typeof json.score === "number" ? json.score : findScoreRecursive(json);
      return {
        provider: "Agent texte",
        ok: true,
        score,
        label: scoreToLabel(score),
        detail: score !== null ? `Score renvoyé par Sapling : ${(score * 100).toFixed(1)}%.` : "Réponse reçue mais aucun score exploitable trouvé.",
      };
    } catch (err) {
      return { provider: "Agent texte", ok: false, score: null, label: "Erreur réseau", detail: String(err) };
    }
  }

  // --- Nouvel adaptateur de texte Hugging Face ---
  async function huggingfaceAnalyzeText({ text, apiKey, modelId }) {
    const model = modelId || "desklib/ai-text-detector-v1.01";
    if (!text || !text.trim()) {
      return { provider: `Agent HF (${model.split("/").pop()})`, ok: false, score: null, label: "Erreur", detail: "Aucun texte à analyser." };
    }
    if (!apiKey) {
      return { provider: `Agent HF (${model.split("/").pop()})`, ok: false, score: null, label: "Non configuré", detail: "Ajoute ton jeton d'accès Hugging Face dans les Réglages." };
    }
    try {
      const res = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({ inputs: text }),
      });
      const json = await res.json();
      
      if (!res.ok) {
        return { 
          provider: `Agent HF (${model.split("/").pop()})`, 
          ok: false, 
          score: null, 
          label: "Erreur API", 
          detail: json.error || "Requête refusée par Hugging Face." 
        };
      }

      let score = null;
      if (Array.isArray(json) && Array.isArray(json[0])) {
        const predictions = json[0];
        const aiLabels = ["label_1", "ai", "generated", "fake", "machine", "synthetic"];
        const humanLabels = ["label_0", "human", "real", "original"];

        const aiPred = predictions.find(p => aiLabels.some(l => p.label.toLowerCase().includes(l)));
        const humanPred = predictions.find(p => humanLabels.some(l => p.label.toLowerCase().includes(l)));

        if (aiPred) {
          score = aiPred.score;
        } else if (humanPred) {
          score = 1 - humanPred.score;
        } else {
          score = findScoreRecursive(json);
        }
      }

      return {
        provider: `Agent HF (${model.split("/").pop()})`,
        ok: true,
        score,
        label: scoreToLabel(score),
        detail: score !== null ? `Score de probabilité IA : ${(score * 100).toFixed(1)}%.` : "Réponse reçue mais aucun score exploitable trouvé.",
      };
    } catch (err) {
      return { provider: `Agent HF (${model.split("/").pop()})`, ok: false, score: null, label: "Erreur réseau", detail: String(err) };
    }
  }

  root.ProvProviders = {
    sightengineAnalyze,
    customProviderAnalyze,
    customProviderAnalyzeText,
    saplingAnalyzeText,
    huggingfaceAnalyzeText,
    findScoreRecursive,
    scoreToLabel,
  };
})(typeof self !== "undefined" ? self : this);