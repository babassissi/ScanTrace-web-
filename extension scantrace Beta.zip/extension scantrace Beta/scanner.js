// Provenance — shared metadata scanner
// Loaded both as a classic <script> in the popup and via importScripts()
// in the background service worker, so it must stay dependency-free.

(function (root) {
  const AI_TOOL_SIGNATURES = [
    "Midjourney",
    "DALL-E",
    "DALL·E",
    "OpenAI",
    "Stable Diffusion",
    "stability.ai",
    "StabilityAI",
    "NovelAI",
    "Adobe Firefly",
    "Firefly",
    "Leonardo.Ai",
    "Ideogram",
    "RunwayML",
    "Runway",
    "Google DeepMind",
    "Imagen",
    "Veo",
    "Gemini",
    "Kling",
    "Sora",
    "PixVerse",
    "Pika Labs",
    "ComfyUI",
    "InvokeAI",
    "Automatic1111",
  ];

  const C2PA_MARKERS = ["c2pa", "C2PA", "urn:c2pa", "Content Credentials", "jumbf", "JUMBF"];

  function scanBytes(bytes, sizeKB) {
    let raw = "";
    const chunkSize = 0x8000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      raw += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
    }

    const foundC2pa = C2PA_MARKERS.find((m) => raw.includes(m));
    if (foundC2pa) {
      return {
        verdict: "credentials",
        detail:
          "Des métadonnées de provenance C2PA (Content Credentials) sont présentes dans le fichier. Cela signifie qu'un historique d'édition/génération a été signé numériquement — souvent par un outil IA ou un logiciel de retouche compatible.",
        sizeKB,
      };
    }

    const foundTool = AI_TOOL_SIGNATURES.find((m) => raw.includes(m));
    if (foundTool) {
      return {
        verdict: "ai_signature",
        detail: `Une référence à l'outil « ${foundTool} » a été trouvée dans les métadonnées du fichier.`,
        sizeKB,
      };
    }

    if (raw.includes("Steps:") && raw.includes("Sampler:")) {
      return {
        verdict: "ai_signature",
        detail:
          "Des paramètres de génération typiques d'un modèle de diffusion (Steps / Sampler / CFG scale) ont été trouvés directement dans le fichier.",
        sizeKB,
      };
    }

    return {
      verdict: "no_signal",
      detail:
        "Aucune métadonnée de provenance ni signature d'outil IA connue n'a été trouvée. Cela ne prouve pas que le contenu est authentique : les métadonnées sont souvent supprimées lors d'un export, d'une capture d'écran ou d'un partage sur les réseaux sociaux.",
      sizeKB,
    };
  }

  root.ProvScanner = { scanBytes };
})(typeof self !== "undefined" ? self : this);
