// ScanTrace — background service worker (Version complète autonome restaurée d'origine, sécurisée par Proxy Vercel actif, multi-agents, capture d'écran, oEmbed, quotas, résolveurs de liens et Post Hybride)

// Table de correspondance pour stocker et annuler les requêtes en cours
const activeAnalyses = new Map(); // itemId -> AbortController

// SIGNATURE DE SÉCURITÉ CLIENT (Pour valider les requêtes auprès de votre Proxy Vercel)
const SCANTRACE_CLIENT_SIGNATURE = "scantrace_beta_secret_token_2026_secure";

// INITIALISATION AUTOMATIQUE DES CLÉS ET QUOTAS DE LA BÊTA LORS DE L'INSTALLATION (Clés vides et quotas bridés par sécurité)
chrome.runtime.onInstalled.addListener(async () => {
  const { provConfig } = await chrome.storage.local.get("provConfig");
  if (!provConfig) {
    const defaultBetaConfig = {
      sightengine: {
        apiUser: "", // Géré par le Proxy Vercel
        apiSecret: "", // Géré par le Proxy Vercel
        enabled: true,
        dailyLimit: 7, // Quota de sécurité par personne
        safetyMargin: 1
      },
      sapling: {
        publicKey: "", // Géré par le Proxy Vercel
        privateKey: "", // Géré par le Proxy Vercel
        enabled: true,
        dailyLimit: 6, // Quota de sécurité par personne
        safetyMargin: 1
      },
      huggingface: {
        apiKey: "", // Géré par le Proxy Vercel
        modelId: "openai-community/roberta-base-openai-detector",
        enabled: true,
        dailyLimit: 20, // Quota de sécurité par personne
        safetyMargin: 2
      },
      huggingface_image: {
        apiKey: "", // Géré par le Proxy Vercel
        modelId: "umm-maybe/AI-image-detector",
        enabled: true,
        dailyLimit: 20, // Quota de sécurité par personne
        safetyMargin: 2
      },
      post: {
        enabled: true
      },
      custom: []
    };
    await chrome.storage.local.set({ 
      provConfig: defaultBetaConfig,
      prov_hf_key: "",
      prov_hf_enabled: true,
      prov_hf_model: "openai-community/roberta-base-openai-detector",
      
      prov_hf_image_key: "",
      prov_hf_image_enabled: true,
      prov_hf_image_model: "umm-maybe/AI-image-detector"
    });
  }
});

// Scanner local
function scanBytes(bytes, sizeKB) {
  const AI_TOOL_SIGNATURES = [
    "Midjourney", "DALL-E", "DALL·E", "OpenAI", "Stable Diffusion", "stability.ai", "StabilityAI",
    "NovelAI", "Adobe Firefly", "Firefly", "Leonardo.Ai", "Ideogram", "RunwayML", "Runway",
    "Google DeepMind", "Imagen", "Veo", "Gemini", "Kling", "Sora", "PixVerse", "Pika Labs",
    "ComfyUI", "InvokeAI", "Automatic1111"
  ];
  const C2PA_MARKERS = ["c2pa", "C2PA", "urn:c2pa", "Content Credentials", "jumbf", "JUMBF"];
  let raw = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    raw += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  const foundC2pa = C2PA_MARKERS.find((m) => raw.includes(m));
  if (foundC2pa) return { verdict: "credentials", detail: "Des métadonnées de provenance C2PA sont présentes.", sizeKB };
  const foundTool = AI_TOOL_SIGNATURES.find((m) => raw.includes(m));
  if (foundTool) return { verdict: "ai_signature", detail: `Une référence à l'outil « ${foundTool} » a été trouvée.`, sizeKB };
  if (raw.includes("Steps:") && raw.includes("Sampler:")) {
    return { verdict: "ai_signature", detail: "Des paramètres de génération de diffusion ont été trouvés.", sizeKB };
  }
  return { verdict: "no_signal", detail: "Aucune métadonnée de provenance trouvée.", sizeKB };
}

// Quotas
function todayStr() { return new Date().toISOString().slice(0, 10); }
async function usedToday(providerId) {
  const { provUsage = {} } = await chrome.storage.local.get("provUsage");
  const rec = provUsage[providerId];
  if (!rec || rec.date !== todayStr()) return 0;
  return rec.count;
}
async function recordCall(providerId) {
  const { provUsage = {} } = await chrome.storage.local.get("provUsage");
  const today = todayStr();
  const rec = provUsage[providerId];
  if (!rec || rec.date !== today) {
    provUsage[providerId] = { date: today, count: 1 };
  } else {
    provUsage[providerId] = { date: today, count: rec.count + 1 };
  }
  await chrome.storage.local.set({ provUsage });
}
async function callWithQuota(providerId, dailyLimit, safetyMargin, providerName, fn) {
  const limit = Number(dailyLimit) || 0;
  const margin = Number(safetyMargin) || 0;
  let allowed = true, used = 0, cap = Infinity;
  if (limit > 0) {
    used = await usedToday(providerId);
    cap = Math.max(0, limit - margin);
    allowed = used < cap;
  }
  if (!allowed) {
    return {
      provider: providerName, ok: false, score: null, label: "Quota atteint",
      detail: `Marge de sécurité atteinte (${used}/${cap} requêtes utilisées). Agent ignoré.`, skipped: true
    };
  }
  const result = await fn();
  await recordCall(providerId);
  return result;
}

// Helpers d'IA
function scoreToLabel(score) {
  if (score === null) return "Score indisponible";
  if (score >= 0.7) return "Probablement généré par IA";
  if (score >= 0.35) return "Incertain";
  return "Probablement authentique";
}
function findScoreRecursive(obj, depth = 0) {
  if (depth > 6 || obj === null || obj === undefined) return null;
  if (typeof obj === "number") return null;
  if (typeof obj !== "object") return null;
  const hints = ["ai_generated", "ai_score", "ai_probability", "fake_probability", "probability", "score"];
  for (const key of Object.keys(obj)) {
    const val = obj[key];
    const keyLower = key.toLowerCase();
    if (typeof val === "number" && val >= 0 && val <= 1 && hints.some((h) => keyLower.includes(h))) return val;
  }
  for (const key of Object.keys(obj)) {
    const val = obj[key];
    if (val && typeof val === "object") {
      const found = findScoreRecursive(val, depth + 1);
      if (found !== null) return found;
    }
  }
  return null;
}

// Découpage du texte pour l'analyse
function splitTextIntoChunks(text, maxLength = 1000) {
  const chunks = [];
  let currentIndex = 0;
  while (currentIndex < text.length) {
    let chunk = text.slice(currentIndex, currentIndex + maxLength);
    if (currentIndex + maxLength < text.length) {
      const lastSpace = chunk.lastIndexOf(" ");
      if (lastSpace > maxLength * 0.7) chunk = chunk.slice(0, lastSpace);
    }
    chunks.push(chunk);
    currentIndex += chunk.length;
  }
  return chunks;
}

function extractMetaTag(html, property) {
  const idx = html.indexOf(property);
  if (idx === -1) return null;
  const slice = html.slice(Math.max(0, idx - 100), idx + 300);
  const match = slice.match(/content=["']([^"']*)["']/i);
  return match ? match[1] : null;
}

function calculateImageConsensus(scored) {
  if (scored.length === 0) return null;
  let weightedScore = null;
  
  const seRes = scored.find(r => r.provider.includes("Vision-Pro") || r.provider.includes("SE") || r.provider.includes("image/vidéo"));
  const hfRes = scored.find(r => r.provider.includes("Deep-Check") || r.provider.includes("HF"));

  if (seRes && hfRes) {
    weightedScore = (seRes.score * 0.75) + (hfRes.score * 0.25);
  } else if (seRes) {
    weightedScore = seRes.score;
  } else if (hfRes) {
    weightedScore = hfRes.score;
  } else {
    weightedScore = scored.reduce((sum, r) => sum + r.score, 0) / scored.length;
  }

  return { avgScore: weightedScore, label: scoreToLabel(weightedScore), agentCount: scored.length };
}

// ── FONCTIONS D'APPELS AUX APIS SÉCURISÉES PAR VOTRE PROXY VERCEL ACTIF ──

// 1. Analyse Sémantique via votre Proxy personnel actif (Ex-Sapling)
async function saplingAnalyzeText({ text }) {
  if (!text || !text.trim()) return { provider: "Analyseur Sémantique", ok: false, score: null, label: "Erreur", detail: "Aucun texte." };
  try {
    const res = await fetch("https://scantrace-proxy-cnh7.vercel.app/api/sapling", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "X-ScanTrace-Signature": SCANTRACE_CLIENT_SIGNATURE // Envoi sécurisé de la signature d'accès
      },
      body: JSON.stringify({ text })
    });
    const json = await res.json();
    if (!res.ok) return { provider: "Analyseur Sémantique", ok: false, score: null, label: "Erreur API", detail: json.error || "Requête refusée." };
    const score = typeof json.score === "number" ? json.score : findScoreRecursive(json);
    return { provider: "Analyseur Sémantique", ok: true, score, label: scoreToLabel(score), detail: `Score de conformité : ${(score * 100).toFixed(1)}%.` };
  } catch (err) {
    return { provider: "Analyseur Sémantique", ok: false, score: null, label: "Erreur réseau", detail: String(err) };
  }
}

// 2. Analyse Syntax-AI via votre Proxy personnel actif (Ex-Hugging Face Text)
async function huggingfaceAnalyzeText({ text, modelId }) {
  const model = modelId || "openai-community/roberta-base-openai-detector";
  const chunks = splitTextIntoChunks(text, 1000);
  const chunksToAnalyze = chunks.slice(0, 5);
  try {
    const promises = chunksToAnalyze.map(async (chunk) => {
      const res = await fetch("https://scantrace-proxy-cnh7.vercel.app/api/huggingface-text", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "X-ScanTrace-Signature": SCANTRACE_CLIENT_SIGNATURE // Envoi sécurisé de la signature d'accès
        },
        body: JSON.stringify({ inputs: chunk, model: model })
      });
      const resText = await res.text();
      let json = {};
      try { json = JSON.parse(resText); } catch (e) {}
      if (!res.ok) throw new Error(json.error || resText);
      let chunkScore = null;
      if (Array.isArray(json) && Array.isArray(json[0])) {
        const predictions = json[0];
        const aiPred = predictions.find(p => ["label_1", "ai", "generated", "fake"].some(l => p.label.toLowerCase().includes(l)));
        const humanPred = predictions.find(p => ["label_0", "human", "real", "original"].some(l => p.label.toLowerCase().includes(l)));
        if (aiPred) chunkScore = aiPred.score;
        else if (humanPred) chunkScore = 1 - humanPred.score;
        else chunkScore = findScoreRecursive(json);
      }
      return chunkScore;
    });
    const chunkScores = await Promise.all(promises);
    const validScores = chunkScores.filter(s => s !== null);
    if (validScores.length === 0) return { provider: `Moteur Syntax-AI`, ok: false, score: null, label: "Erreur API", detail: "Aucun score." };
    const avgScore = validScores.reduce((sum, s) => sum + s, 0) / validScores.length;
    return { provider: `Moteur Syntax-AI`, ok: true, score: avgScore, label: scoreToLabel(avgScore), detail: `Score moyen : ${(avgScore * 100).toFixed(1)}%.` };
  } catch (err) {
    return { provider: `Moteur Syntax-AI`, ok: false, score: null, label: "Erreur API", detail: String(err.message || err) };
  }
}

// 3. Analyse Deep-Check via votre Proxy personnel actif (Ex-Hugging Face Image)
async function huggingfaceAnalyzeImage({ file, modelId }) {
  const model = modelId || "umm-maybe/AI-image-detector";
  if (!file) return { provider: `Moteur Deep-Check`, ok: false, score: null, label: "Erreur", detail: "Aucun fichier à analyser." };
  try {
    const res = await fetch(`https://scantrace-proxy-cnh7.vercel.app/api/huggingface-image?model=${encodeURIComponent(model)}`, {
      method: "POST",
      headers: {
        "X-ScanTrace-Signature": SCANTRACE_CLIENT_SIGNATURE // Envoi sécurisé de la signature d'accès
      },
      body: file
    });
    const resText = await res.text();
    let json = {};
    try { json = JSON.parse(resText); } catch (e) {}

    if (!res.ok) return { provider: `Moteur Deep-Check`, ok: false, score: null, label: "Erreur API", detail: json.error || resText || "Requête refusée." };

    let score = null;
    if (Array.isArray(json)) {
      const aiLabels = ["artificial", "ai", "fake", "generated", "synthetic"];
      const humanLabels = ["human", "real", "natural", "original"];

      const aiPred = json.find(p => aiLabels.some(l => p.label.toLowerCase().includes(l)));
      const humanPred = json.find(p => humanLabels.some(l => p.label.toLowerCase().includes(l)));

      if (aiPred) score = aiPred.score;
      else if (humanPred) score = 1 - humanPred.score;
      else score = findScoreRecursive(json);
    }
    return { provider: `Moteur Deep-Check`, ok: true, score, label: scoreToLabel(score), detail: `Score : ${(score * 100).toFixed(1)}%.` };
  } catch (err) {
    return { provider: `Moteur Deep-Check`, ok: false, score: null, label: "Erreur réseau", detail: String(err) };
  }
}

// 4. Analyse Vision-Pro via votre Proxy personnel actif (Ex-Sightengine)
async function sightengineAnalyze({ file }) {
  if (!file) return { provider: "Moteur Vision-Pro", ok: false, score: null, label: "Erreur", detail: "Aucune source à analyser." };
  try {
    const res = await fetch("https://scantrace-proxy-cnh7.vercel.app/api/sightengine", {
      method: "POST",
      headers: { 
        "Content-Type": file.type || "image/jpeg",
        "X-ScanTrace-Signature": SCANTRACE_CLIENT_SIGNATURE // Envoi sécurisé de la signature d'accès
      },
      body: file
    });
    const json = await res.json();
    if (json.status === "failure") return { provider: "Moteur Vision-Pro", ok: false, score: null, label: "Erreur API", detail: json.error?.message };
    const score = findScoreRecursive(json);
    return { provider: "Moteur Vision-Pro", ok: true, score, label: scoreToLabel(score), detail: `Score : ${(score * 100).toFixed(1)}%.` };
  } catch (err) {
    return { provider: "Moteur Vision-Pro", ok: false, score: null, label: "Erreur réseau", detail: String(err) };
  }
}

// ── LOGIQUE TECHNIQUE DE L'EXTENSION ──

// Déclencheur au clic d'icône d'extension (avec injection dynamique de secours)
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  if (tab.url && (tab.url.startsWith("chrome://") || tab.url.startsWith("chrome-extension://") || tab.url.startsWith("view-source:") || tab.url.startsWith("https://chromewebstore.google.com"))) {
    return;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "PROV_TOGGLE_PANEL" });
  } catch (e) {
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await chrome.tabs.sendMessage(tab.id, { type: "PROV_TOGGLE_PANEL" });
    } catch (e2) {
      console.error("[ScanTrace] Impossible de forcer l'ouverture du panneau :", tab.url, e2);
    }
  }
});

// Écouteur de messages
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) return;
  const msgType = String(msg.type).toUpperCase();
  if (msgType.includes("CAPTURE") || msgType.includes("SCREENSHOT") || msgType.includes("SCREEN")) {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) sendResponse({ ok: false, error: chrome.runtime.lastError.message });
      else sendResponse({ ok: true, dataUrl, image: dataUrl, data: dataUrl });
    });
    return true;
  }
  
  if (msg.type === "PROV_RESOLVE_URL") {
    (async () => {
      try {
        let targetUrl = msg.url.trim();
        if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
          targetUrl = "https://" + targetUrl;
        }

        if (targetUrl.includes("instagram.com")) {
          const instaOembedUrl = `https://graph.facebook.com/v25.0/instagram_oembed?url=${encodeURIComponent(targetUrl)}`;
          const instaRes = await fetch(instaOembedUrl);
          if (instaRes.ok) {
            const json = await instaRes.json();
            sendResponse({ resolvedUrl: json.thumbnail_url || targetUrl });
            return;
          }
        }

        if (targetUrl.includes("twitter.com") || targetUrl.includes("x.com")) {
          const matches = targetUrl.match(/status\/(\d+)/);
          if (matches && matches[1]) {
            const tweetId = matches[1];
            const vxRes = await fetch(`https://api.vxtwitter.com/i/status/${tweetId}`);
            if (vxRes.ok) {
              const json = await vxRes.json();
              const thumbnail = (json.media_extended && json.media_extended[0]) ? (json.media_extended[0].thumbnail_url || json.media_extended[0].url) : "";
              sendResponse({ resolvedUrl: thumbnail || targetUrl });
              return;
            }
          }
        }

        const res = await fetch(targetUrl);
        if (res.ok) {
          const html = await res.text();
          const ogImage = extractMetaTag(html, "og:image") || 
                          extractMetaTag(html, "og:image:secure_url") || 
                          extractMetaTag(html, "twitter:image") || 
                          extractMetaTag(html, "twitter:image:src");
          if (ogImage) {
            const decodedImage = ogImage.replace(/&amp;/g, "&");
            sendResponse({ resolvedUrl: decodedImage });
            return;
          }
        }

        let oembedUrl = "";
        if (targetUrl.includes("tiktok.com")) {
          oembedUrl = `https://www.tiktok.com/oembed?url=${encodeURIComponent(targetUrl)}`;
        } else if (targetUrl.includes("youtube.com") || targetUrl.includes("youtu.be")) {
          oembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(targetUrl)}`;
        }

        if (oembedUrl) {
          const oembedRes = await fetch(oembedUrl);
          if (oembedRes.ok) {
            const json = await oembedRes.json();
            sendResponse({ resolvedUrl: json.thumbnail_url || json.url || targetUrl });
            return;
          }
        }

        sendResponse({ resolvedUrl: targetUrl });
      } catch (err) {
        sendResponse({ resolvedUrl: msg.url });
      }
    })();
    return true;
  }
  
  if (msg.type === "PROV_ABORT_ANALYSIS") {
    const controller = activeAnalyses.get(msg.itemId);
    if (controller) { controller.abort(); activeAnalyses.delete(msg.itemId); }
    sendResponse({ ok: true });
    return;
  }
  if (msg.type === "PROV_OPEN_OPTIONS") { chrome.runtime.openOptionsPage(); return; }
  if (msg.type === "PROV_MEDIA_SELECTED") {
    (async () => {
      try {
        const { provItems = [] } = await chrome.storage.local.get("provItems");
        const newOnes = msg.items.map((it, idx) => ({ id: `${Date.now()}_${idx}`, ...it, status: "pending", result: null }));
        await chrome.storage.local.set({ provItems: [...newOnes, ...provItems] });
        sendResponse({ ok: true, items: newOnes });
      } catch (e) { sendResponse({ ok: false, error: String(e) }); }
    })();
    return true;
  }
  if (msg.type === "PROV_ANALYZE_ITEM") {
    const controller = new AbortController();
    activeAnalyses.set(msg.item.id, controller);
    
    const performAnalysis = msg.item.type === "post" ? analyzePost(msg.item) : analyzeItem(msg.item);

    performAnalysis.then((r) => { activeAnalyses.delete(msg.item.id); sendResponse({ ok: true, result: r }); })
      .catch((e) => { activeAnalyses.delete(msg.item.id); sendResponse({ ok: false, error: String(e) }); });
    return true;
  }
  if (msg.type === "PROV_ANALYZE_TEXT") {
    const controller = new AbortController();
    activeAnalyses.set(msg.itemId, controller);
    analyzeText(msg.text).then((r) => { activeAnalyses.delete(msg.itemId); sendResponse({ ok: true, result: r }); })
      .catch((e) => { activeAnalyses.delete(msg.itemId); sendResponse({ ok: false, error: String(e) }); });
    return true;
  }
  if (msg.type === "PROV_ANALYZE_VIDEO_SAMPLES") {
    analyzeVideoSamples(msg.samples).then((r) => sendResponse({ ok: true, result: r })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
  if (msg.type === "PROV_CLEAR") { chrome.storage.local.set({ provItems: [] }); return; }
});

async function analyzeText(text) {
  const { provConfig } = await chrome.storage.local.get("provConfig");
  const store = await chrome.storage.local.get(["prov_hf_key", "prov_hf_enabled", "prov_hf_model"]);
  const cfg = provConfig || {};
  
  // FORCE L'ACTIVATION TECHNIQUE PAR DÉFAUT DE TOUS LES AGENTS DE TEXTE POUR LE PROXY SÉCURISÉ [1.4.3]
  const sapling = { enabled: true, dailyLimit: 6, safetyMargin: 1, ...(cfg.sapling || {}) };
  const hf = { enabled: true, dailyLimit: 20, safetyMargin: 2, modelId: "openai-community/roberta-base-openai-detector", ...(cfg.huggingface || {}) };

  const finalHfEnabled = store.prov_hf_enabled !== undefined ? store.prov_hf_enabled : hf.enabled;
  const finalHfModel = store.prov_hf_model !== undefined ? store.prov_hf_model : hf.modelId;

  const calls = [];
  
  if (sapling.enabled === true || sapling.enabled === "true") {
    calls.push(callWithQuota("sapling", sapling.dailyLimit, sapling.safetyMargin, "Analyseur Sémantique", () =>
      saplingAnalyzeText({ text })
    ));
  }
  if (finalHfEnabled === true || finalHfEnabled === "true") {
    calls.push(callWithQuota("huggingface", hf.dailyLimit || 20, hf.safetyMargin || 2, "Moteur Syntax-AI", () =>
      huggingfaceAnalyzeText({ text, modelId: finalHfModel })
    ));
  }
  const apiResults = await Promise.all(calls);
  const scored = apiResults.filter((r) => r.ok && typeof r.score === "number");
  
  // CALCUL PONDÉRÉ DU TEXTE AJUSTÉ EN 30/70 (30% Analyseur Sémantique / 70% Moteur Syntax-AI) [1.1.2]
  let consensus = null;
  if (scored.length > 0) {
    let weightedScore = null;
    const saplingRes = scored.find(r => r.provider.includes("Sémantique"));
    const hfRes = scored.find(r => r.provider.includes("Syntax-AI"));

    if (saplingRes && hfRes) {
      weightedScore = (saplingRes.score * 0.3) + (hfRes.score * 0.7); // <-- PONDÉRATION AJUSTÉE ICI !
    } else if (saplingRes) {
      weightedScore = saplingRes.score;
    } else if (hfRes) {
      weightedScore = hfRes.score;
    } else {
      weightedScore = scored.reduce((sum, r) => sum + r.score, 0) / scored.length;
    }

    consensus = { avgScore: weightedScore, label: scoreToLabel(weightedScore), agentCount: scored.length };
  }
  return { localMeta: null, apiResults, consensus };
}

async function analyzeVideoSamples(samples) {
  const { provConfig } = await chrome.storage.local.get("provConfig");
  const cfg = provConfig || { sightengine: { enabled: false } };
  if (!cfg.sightengine?.enabled) return { localMeta: null, apiResults: [], consensus: null };
  const apiResults = await Promise.all(samples.map(async ({ second, bytes }) => {
    return callWithQuota(`sightengine_video_${second}`, cfg.sightengine.dailyLimit, cfg.sightengine.safetyMargin, `Agent vidéo · ${second}s`, () =>
      sightengineAnalyze({
        file: new File([new Uint8Array(bytes)], `extrait-${second}s.jpg`, { type: "image/jpeg" }),
        mediaType: "image"
      })
    );
  }));
  const scored = apiResults.filter((r) => r.ok && typeof r.score === "number");
  const consensus = scored.length ? { avgScore: scored.reduce((s, r) => s + r.length, 0) / scored.length, label: scoreToLabel(scored.reduce((s, r) => s + r.score, 0) / scored.length), agentCount: scored.length } : null;
  return { localMeta: null, apiResults, consensus };
}

async function analyzeItem(item) {
  const { provConfig } = await chrome.storage.local.get("provConfig");
  const defaults = { sightengine: { enabled: false, dailyLimit: 7, safetyMargin: 1 } };
  const cfg = { sightengine: { ...defaults.sightengine, ...(provConfig?.sightengine || {}) } };
  const hfImg = provConfig?.huggingface_image || { modelId: "umm-maybe/AI-image-detector", enabled: false, dailyLimit: 20, safetyMargin: 2 };

  let bytes = null, sizeKB = null, blobForUpload = null;
  try {
    if (item.fileBytes) {
      bytes = new Uint8Array(item.fileBytes); sizeKB = Math.round(bytes.byteLength / 1024);
      blobForUpload = new File([bytes], item.fileName || "media", { type: item.fileType || "" });
    } else if (item.src) {
      const res = await fetch(item.src, { cache: "no-store" });
      if (res.ok) {
        const buf = await res.arrayBuffer(); bytes = new Uint8Array(buf); sizeKB = Math.round(bytes.byteLength / 1024);
        blobForUpload = new File([buf], "media", { type: res.headers.get("content-type") || "image/jpeg" });
      }
    }
  } catch (e) {}
  const localMeta = bytes ? scanBytes(sampleMetadataBytes(bytes), sizeKB) : null;
  const calls = [];
  
  if (cfg.sightengine && cfg.sightengine.enabled) {
    calls.push(callWithQuota("sightengine", cfg.sightengine.dailyLimit, cfg.sightengine.safetyMargin, "Moteur Vision-Pro", () =>
      sightengineAnalyze({ file: blobForUpload })
    ));
  }

  if (hfImg.enabled === true || hfImg.enabled === "true") {
    calls.push(callWithQuota("huggingface_image", hfImg.dailyLimit || 20, hfImg.safetyMargin || 2, "Moteur Deep-Check", () =>
      huggingfaceAnalyzeImage({ file: blobForUpload, modelId: hfImg.modelId })
    ));
  }

  const apiResults = await Promise.all(calls);
  const scored = apiResults.filter((r) => r.ok && typeof r.score === "number");
  
  const consensus = calculateImageConsensus(scored);
  return { localMeta, apiResults, consensus };
}

// RESTAURATION COMPLÈTE DE LA LOGIQUE D'ANALYSE D'ACTE SOCIAL SANS LES EN-TÊTES DE SCRAPING CONFLIGUANT ET AVEC LES CLEFS PLATES ET DE SECOURS PARFAITEMENT RESTAURÉES D'ORIGINE [1.1.5, 1.4.3]
async function analyzePost(item) {
  const { provConfig } = await chrome.storage.local.get("provConfig");
  const store = await chrome.storage.local.get([
    "prov_hf_image_key", "prov_hf_image_enabled", "prov_hf_image_model"
  ]);
  
  // FORCE L'ACTIVATION TECHNIQUE PAR DÉFAUT DE TOUS LES AGENTS (IMAGE & TEXTE) POUR LE PROXY SÉCURISÉ [1.4.3]
  const sightengineEnabled = provConfig?.sightengine?.enabled !== undefined ? provConfig.sightengine.enabled : true;
  const hfImageEnabled = store.prov_hf_image_enabled !== undefined ? store.prov_hf_image_enabled : true;
  
  const hfImg = { enabled: hfImageEnabled, dailyLimit: 20, safetyMargin: 2, modelId: "umm-maybe/AI-image-detector" };
  const cfg = { sightengine: { enabled: sightengineEnabled, dailyLimit: 7, safetyMargin: 1 } };

  // RÉSOLUTION DU BUG DE RÉFÉRENCE : Déclaration explicite et robuste du modèle d'image Hugging Face configuré
  const finalHfImageModel = store.prov_hf_image_model !== undefined ? store.prov_hf_image_model : hfImg.modelId;

  let resolvedText = "";
  let resolvedImgUrl = "";
  const platformUrl = item.pageUrl || item.src || "";
  let isVideoPost = false;

  try {
    if (platformUrl.includes("instagram.com")) {
      if (platformUrl.includes("reel/") || platformUrl.includes("tv/")) {
        isVideoPost = true;
      }
      const matches = platformUrl.match(/(?:p|reel|tv)\/([a-zA-Z0-9_-]+)/);
      if (matches && matches[1]) {
        resolvedImgUrl = `https://www.instagram.com/p/${matches[1]}/media/?size=l`;
      }
      const oembedRes = await fetch(`https://graph.facebook.com/v25.0/instagram_oembed?url=${encodeURIComponent(platformUrl)}`);
      if (oembedRes.ok) {
        const json = await oembedRes.json();
        resolvedText = json.title || "";
      }
    } else if (platformUrl.includes("twitter.com") || platformUrl.includes("x.com")) {
      const matches = platformUrl.match(/status\/(\d+)/);
      if (matches && matches[1]) {
        const tweetId = matches[1];
        const res = await fetch(`https://api.vxtwitter.com/i/status/${tweetId}`);
        if (res.ok) {
          const json = await res.json();
          resolvedText = json.text || "";
          if (json.media_extended && json.media_extended[0]) {
            resolvedImgUrl = json.media_extended[0].thumbnail_url || json.media_extended[0].url || "";
            if (json.media_extended[0].type === "video" || json.media_extended[0].type === "gif") {
              isVideoPost = true;
            }
          }
        }
      }
    } else if (platformUrl.includes("tiktok.com")) {
      isVideoPost = true;
      const res = await fetch(`https://www.tiktok.com/oembed?url=${encodeURIComponent(platformUrl)}`);
      if (res.ok) {
        const json = await res.json();
        resolvedText = json.title || "";
        resolvedImgUrl = json.thumbnail_url || "";
      }
    } else if (platformUrl.includes("youtube.com") || platformUrl.includes("youtu.be")) {
      isVideoPost = true;
      const res = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(platformUrl)}`);
      if (res.ok) {
        // CORRECTION DE VARIABLE : Rétablissement de res.json() à la place de l'ancienne variable indéfinie oembedRes
        const json = await res.json(); 
        resolvedText = json.title || "";
        resolvedImgUrl = json.thumbnail_url || "";
      }
    } else {
      const res = await fetch(platformUrl);
      if (res.ok) {
        const html = await res.text();
        resolvedText = extractMetaTag(html, "og:description") || extractMetaTag(html, "twitter:description") || "";
        resolvedImgUrl = extractMetaTag(html, "og:image") || extractMetaTag(html, "twitter:image") || "";
        const ogType = extractMetaTag(html, "og:type");
        if (ogType && ogType.toLowerCase().includes("video")) {
          isVideoPost = true;
        }
      }
    }
  } catch (err) {
    console.warn("[ScanTrace background] Post data resolution failed:", err);
  }

  let imageBlob = null;
  if (resolvedImgUrl) {
    try {
      const imgRes = await fetch(resolvedImgUrl, { cache: "no-store" });
      if (imgRes.ok) {
        const buf = await imgRes.arrayBuffer();
        // Utilisation de Blob (100% compatible Service Worker) à la place de File
        imageBlob = new Blob([buf], { type: imgRes.headers.get("content-type") || "image/jpeg" });
      }
    } catch (e) {
      console.warn("[ScanTrace background] Failed to download resolved post image:", e);
    }
  }

  const postCalls = [];

  if (resolvedText && resolvedText.trim().length > 0) {
    postCalls.push(analyzeText(resolvedText).then(res => {
      if (res && res.apiResults) {
        res.apiResults = res.apiResults.map(r => ({
          ...r,
          provider: `[Texte] ${r.provider}` // Retrait du .replace() pour plus de propreté visuelle
        }));
      }
      return { ...res, kind: "text" };
    }));
  }

  if (imageBlob) {
    const imgCalls = [];
    const labelPrefix = isVideoPost ? "[Vidéo (Miniature)]" : "[Visuel]";

    if (cfg.sightengine.enabled) {
      imgCalls.push(callWithQuota("sightengine", cfg.sightengine.dailyLimit, cfg.sightengine.safetyMargin, `${labelPrefix} Moteur Vision-Pro`, () =>
        sightengineAnalyze({ file: imageBlob })
      ));
    }
    
    // RESTAURATION EXPLICITE DE hfImageEnabled POUR L'APPEL DES AGENTS D'IMAGES DE PUBLICATIONS SÉCURISÉES
    if (hfImageEnabled === true || hfImageEnabled === "true") {
      imgCalls.push(callWithQuota("huggingface_image", hfImg.dailyLimit || 1000, hfImg.safetyMargin || 10, `${labelPrefix} Moteur Deep-Check`, () =>
        huggingfaceAnalyzeImage({ file: imageBlob, modelId: finalHfImageModel })
      ));
    }

    if (imgCalls.length > 0) {
      postCalls.push(Promise.all(imgCalls).then(apiResults => {
        const consensus = calculateImageConsensus(apiResults);
        return { apiResults, consensus, kind: "image" };
      }));
    }
  }

  const results = await Promise.all(postCalls);

  const combinedApiResults = [];
  let textScore = null;
  let imageScore = null;

  for (const r of results) {
    if (r && r.apiResults) {
      combinedApiResults.push(...r.apiResults);
    }
    if (r && r.consensus && r.consensus.avgScore !== null) {
      if (r.kind === "text") textScore = r.consensus.avgScore;
      if (r.kind === "image") imageScore = r.consensus.avgScore;
    }
  }

  return { 
    localMeta: null, 
    apiResults: combinedApiResults, 
    consensusText: textScore !== null ? { avgScore: textScore, label: scoreToLabel(textScore) } : null,
    consensusImage: imageScore !== null ? { avgScore: imageScore, label: scoreToLabel(imageScore) } : null,
    consensus: null
  };
}

function sampleMetadataBytes(bytes) {
  const sampleSize = 2 * 1024 * 1024;
  if (bytes.length <= sampleSize * 2) return bytes;
  const sample = new Uint8Array(sampleSize * 2);
  sample.set(bytes.subarray(0, sampleSize));
  sample.set(bytes.subarray(bytes.length - sampleSize), sampleSize);
  return sample;
}