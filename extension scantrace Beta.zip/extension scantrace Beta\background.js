// ScanTrace — background.js (Version API centralisée)
// Toute la logique d'analyse est maintenant dans /api/analyze sur le proxy Vercel.
// Ce fichier ne fait qu'envoyer le contenu et recevoir le résultat.

const PROXY_URL = "https://scantrace-proxy-cnh7.vercel.app";
const SCANTRACE_CLIENT_SIGNATURE = "scantrace_beta_secret_token_2026_secure";

const activeAnalyses = new Map();

// ── INITIALISATION ──────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async () => {
  const { provConfig } = await chrome.storage.local.get("provConfig");
  if (!provConfig) {
    await chrome.storage.local.set({
      provConfig: {
        sightengine: { enabled: true, dailyLimit: 7, safetyMargin: 1 },
        sapling: { enabled: true, dailyLimit: 6, safetyMargin: 1 },
        huggingface: { enabled: true, dailyLimit: 20, safetyMargin: 2 },
        huggingface_image: { enabled: true, dailyLimit: 20, safetyMargin: 2 },
        post: { enabled: true },
        custom: []
      },
      prov_hf_enabled: true,
      prov_hf_image_enabled: true
    });
  }
});

// ── APPEL API CENTRALE ──────────────────────────────────────────────────

async function apiAnalyzeJson(body) {
  const res = await fetch(`${PROXY_URL}/api/analyze`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-ScanTrace-Signature": SCANTRACE_CLIENT_SIGNATURE
    },
    body: JSON.stringify(body)
  });
  return res.json();
}

async function apiAnalyzeFile(file, type = "image") {
  const res = await fetch(`${PROXY_URL}/api/analyze?type=${type}`, {
    method: "POST",
    headers: {
      "Content-Type": file.type || "image/jpeg",
      "X-ScanTrace-Signature": SCANTRACE_CLIENT_SIGNATURE
    },
    body: file
  });
  return res.json();
}

// ── CONVERSION API → FORMAT PANEL ───────────────────────────────────────
// Le panneau (content.js) attend { localMeta, apiResults, consensus,
// consensusText?, consensusImage? } — on traduit la réponse API.

function apiToPanel(data) {
  if (!data || !data.ok) {
    return {
      localMeta: null,
      apiResults: [{ provider: "API ScanTrace", ok: false, score: null, label: "Erreur", detail: data?.error || "Erreur inconnue" }],
      consensus: null
    };
  }
  return {
    localMeta: data.localMeta || null,
    apiResults: (data.agents || []).map(a => ({
      provider: a.provider,
      ok: a.ok,
      score: a.score,
      label: a.label,
      detail: a.detail,
      skipped: a.skipped || false
    })),
    consensus: data.consensus?.score !== null ? {
      avgScore: data.consensus.score,
      label: data.consensus.label,
      agentCount: (data.agents || []).filter(a => a.ok && a.score !== null).length
    } : null,
    consensusText: data.consensusText?.score !== null && data.consensusText ? {
      avgScore: data.consensusText.score,
      label: data.consensusText.label
    } : null,
    consensusImage: data.consensusImage?.score !== null && data.consensusImage ? {
      avgScore: data.consensusImage.score,
      label: data.consensusImage.label
    } : null,
  };
}

// ── FONCTIONS D'ANALYSE ─────────────────────────────────────────────────

async function analyzeItem(item) {
  let file = null;

  if (item.fileBytes) {
    const bytes = new Uint8Array(item.fileBytes);
    file = new Blob([bytes], { type: item.fileType || "image/jpeg" });
  } else if (item.src) {
    try {
      const res = await fetch(item.src, { cache: "no-store" });
      if (res.ok) {
        const buf = await res.arrayBuffer();
        file = new Blob([buf], { type: res.headers.get("content-type") || "image/jpeg" });
      }
    } catch (e) {}
  }

  if (file) {
    const data = await apiAnalyzeFile(file, "image");
    return apiToPanel(data);
  }

  return {
    localMeta: null,
    apiResults: [{ provider: "API ScanTrace", ok: false, score: null, label: "Erreur", detail: "Aucune source à analyser." }],
    consensus: null
  };
}

async function analyzeText(text) {
  const data = await apiAnalyzeJson({ type: "text", text });
  return apiToPanel(data);
}

async function analyzePost(item) {
  const url = item.pageUrl || item.src || "";
  const data = await apiAnalyzeJson({ type: "post", url });
  return apiToPanel(data);
}

async function analyzeVideoSamples(samples) {
  // Analyse chaque échantillon vidéo comme une image
  const allResults = [];
  for (const { second, bytes } of samples) {
    const blob = new Blob([new Uint8Array(bytes)], { type: "image/jpeg" });
    const data = await apiAnalyzeFile(blob, "image");
    if (data.ok && data.agents) {
      data.agents.forEach(a => {
        allResults.push({ ...a, provider: `Agent vidéo · ${second}s — ${a.provider}` });
      });
    }
  }
  const scored = allResults.filter(r => r.ok && typeof r.score === "number");
  const avgScore = scored.length ? scored.reduce((s, r) => s + r.score, 0) / scored.length : null;
  return {
    localMeta: null,
    apiResults: allResults,
    consensus: avgScore !== null ? {
      avgScore,
      label: avgScore >= 0.7 ? "Probablement généré par IA" : avgScore >= 0.35 ? "Incertain" : "Probablement authentique",
      agentCount: scored.length
    } : null
  };
}

// ── HELPERS (toujours nécessaires pour content.js) ──────────────────────

function extractMetaTag(html, property) {
  const idx = html.indexOf(property);
  if (idx === -1) return null;
  const slice = html.slice(Math.max(0, idx - 100), idx + 300);
  const match = slice.match(/content=["']([^"']*)["']/i);
  return match ? match[1] : null;
}

// ── ÉCOUTEURS DE MESSAGES (inchangés — content.js les appelle) ──────────

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  if (tab.url && (tab.url.startsWith("chrome://") || tab.url.startsWith("chrome-extension://") || tab.url.startsWith("view-source:") || tab.url.startsWith("https://chromewebstore.google.com"))) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "PROV_TOGGLE_PANEL" });
  } catch (e) {
    try {
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] });
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await chrome.tabs.sendMessage(tab.id, { type: "PROV_TOGGLE_PANEL" });
    } catch (e2) {
      console.error("[ScanTrace] Impossible d'ouvrir le panneau :", tab.url, e2);
    }
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) return;
  const msgType = String(msg.type).toUpperCase();

  if (msgType.includes("CAPTURE") || msgType.includes("SCREENSHOT") || msgType.includes("SCREEN")) {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) sendResponse({ ok: false, error: chrome.runtime.lastError.message });
      else sendResponse({ ok: true, dataUrl, image: dataUrl, data: dataUrl });
    });
    return true;
  }

  if (msg.type === "PROV_RESOLVE_URL") {
    (async () => {
      try {
        let targetUrl = msg.url.trim();
        if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) targetUrl = "https://" + targetUrl;

        if (targetUrl.includes("instagram.com")) {
          const r = await fetch(`https://graph.facebook.com/v25.0/instagram_oembed?url=${encodeURIComponent(targetUrl)}`);
          if (r.ok) { const j = await r.json(); sendResponse({ resolvedUrl: j.thumbnail_url || targetUrl }); return; }
        }
        if (targetUrl.includes("twitter.com") || targetUrl.includes("x.com")) {
          const m = targetUrl.match(/status\/(\d+)/);
          if (m) {
            const r = await fetch(`https://api.vxtwitter.com/i/status/${m[1]}`);
            if (r.ok) { const j = await r.json(); const med = j.media_extended?.[0]; if (med) { sendResponse({ resolvedUrl: med.thumbnail_url || med.url || targetUrl }); return; } }
          }
        }

        const res = await fetch(targetUrl);
        if (res.ok) {
          const html = await res.text();
          const ogImage = extractMetaTag(html, "og:image") || extractMetaTag(html, "og:image:secure_url") || extractMetaTag(html, "twitter:image") || extractMetaTag(html, "twitter:image:src");
          if (ogImage) { sendResponse({ resolvedUrl: ogImage.replace(/&amp;/g, "&") }); return; }
        }

        let oembedUrl = "";
        if (targetUrl.includes("tiktok.com")) oembedUrl = `https://www.tiktok.com/oembed?url=${encodeURIComponent(targetUrl)}`;
        else if (targetUrl.includes("youtube.com") || targetUrl.includes("youtu.be")) oembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(targetUrl)}`;
        if (oembedUrl) {
          const r = await fetch(oembedUrl);
          if (r.ok) { const j = await r.json(); sendResponse({ resolvedUrl: j.thumbnail_url || j.url || targetUrl }); return; }
        }
        sendResponse({ resolvedUrl: targetUrl });
      } catch (err) { sendResponse({ resolvedUrl: msg.url }); }
    })();
    return true;
  }

  if (msg.type === "PROV_ABORT_ANALYSIS") {
    const controller = activeAnalyses.get(msg.itemId);
    if (controller) { controller.abort(); activeAnalyses.delete(msg.itemId); }
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "PROV_OPEN_OPTIONS") { chrome.runtime.openOptionsPage(); return; }

  if (msg.type === "PROV_MEDIA_SELECTED") {
    (async () => {
      try {
        const { provItems = [] } = await chrome.storage.local.get("provItems");
        const newOnes = msg.items.map((it, idx) => ({ id: `${Date.now()}_${idx}`, ...it, status: "pending", result: null }));
        await chrome.storage.local.set({ provItems: [...newOnes, ...provItems] });
        sendResponse({ ok: true, items: newOnes });
      } catch (e) { sendResponse({ ok: false, error: String(e) }); }
    })();
    return true;
  }

  if (msg.type === "PROV_ANALYZE_ITEM") {
    const controller = new AbortController();
    activeAnalyses.set(msg.item.id, controller);
    const performAnalysis = msg.item.type === "post" ? analyzePost(msg.item) : analyzeItem(msg.item);
    performAnalysis.then((r) => { activeAnalyses.delete(msg.item.id); sendResponse({ ok: true, result: r }); })
      .catch((e) => { activeAnalyses.delete(msg.item.id); sendResponse({ ok: false, error: String(e) }); });
    return true;
  }

  if (msg.type === "PROV_ANALYZE_TEXT") {
    const controller = new AbortController();
    activeAnalyses.set(msg.itemId, controller);
    analyzeText(msg.text).then((r) => { activeAnalyses.delete(msg.itemId); sendResponse({ ok: true, result: r }); })
      .catch((e) => { activeAnalyses.delete(msg.itemId); sendResponse({ ok: false, error: String(e) }); });
    return true;
  }

  if (msg.type === "PROV_ANALYZE_VIDEO_SAMPLES") {
    analyzeVideoSamples(msg.samples).then((r) => sendResponse({ ok: true, result: r })).catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }

  if (msg.type === "PROV_CLEAR") { chrome.storage.local.set({ provItems: [] }); return; }
});