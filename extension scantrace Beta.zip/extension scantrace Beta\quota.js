// Provenance — quota.js
// Tracks daily call counts per provider in chrome.storage.local and refuses
// to call a provider once it gets within `safetyMargin` calls of the free
// quota the user configured for it in the Réglages page.
// Loaded via importScripts() in background.js and as a <script> in options.js.

(function (root) {
  function todayStr() {
    return new Date().toISOString().slice(0, 10);
  }

  async function getUsage() {
    const { provUsage = {} } = await chrome.storage.local.get("provUsage");
    return provUsage;
  }

  // Returns the current count for a provider, resetting it to 0 first if
  // the stored count is from a previous day.
  async function usedToday(providerId) {
    const usage = await getUsage();
    const rec = usage[providerId];
    if (!rec || rec.date !== todayStr()) return 0;
    return rec.count;
  }

  // dailyLimit  = free quota advertised by the provider (set by the user)
  // safetyMargin = number of calls to keep in reserve, never actually used
  // Effective cap = max(0, dailyLimit - safetyMargin)
  async function checkQuota(providerId, dailyLimit, safetyMargin) {
    const limit = Number(dailyLimit) || 0;
    const margin = Number(safetyMargin) || 0;
    if (limit <= 0) return { allowed: true, used: 0, cap: Infinity }; // no limit set = unlimited/unchecked

    const used = await usedToday(providerId);
    const cap = Math.max(0, limit - margin);
    return { allowed: used < cap, used, cap };
  }

  async function recordCall(providerId) {
    const usage = await getUsage();
    const today = todayStr();
    const rec = usage[providerId];
    if (!rec || rec.date !== today) {
      usage[providerId] = { date: today, count: 1 };
    } else {
      usage[providerId] = { date: today, count: rec.count + 1 };
    }
    await chrome.storage.local.set({ provUsage: usage });
  }

  async function resetProvider(providerId) {
    const usage = await getUsage();
    delete usage[providerId];
    await chrome.storage.local.set({ provUsage: usage });
  }

  // Wraps a provider call: checks the quota first, skips (without ever
  // hitting the network) if the safety margin is reached, otherwise makes
  // the call and records it. Every provider result — including a skipped
  // one — is shaped like the objects returned by providers.js so the
  // popup can render it the same way.
  async function callWithQuota(providerId, dailyLimit, safetyMargin, providerName, fn) {
    const { allowed, used, cap } = await checkQuota(providerId, dailyLimit, safetyMargin);
    if (!allowed) {
      return {
        provider: providerName,
        ok: false,
        score: null,
        label: "Quota atteint",
        detail: `Marge de sécurité atteinte (${used}/${cap} requêtes déjà utilisées aujourd'hui). Cet agent est ignoré pour éviter de dépasser l'offre gratuite. Réinitialisation à minuit.`,
        skipped: true,
      };
    }
    const result = await fn();
    await recordCall(providerId);
    return result;
  }

  root.ProvQuota = { checkQuota, recordCall, usedToday, resetProvider, todayStr, callWithQuota };
})(typeof self !== "undefined" ? self : this);
